package net;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JTextArea;

public class Client implements Runnable
{
	private JTextArea area;
	private Socket socket;
	public Client(JTextArea area) {
		this.area=area;
	}

	public void startClient() throws UnknownHostException, IOException {
		socket=new Socket("127.0.0.1",8000); //si poteva scrivere "localhost"
		Thread t=new Thread(this);
		t.start();
	}

	public void sendMessage(String text) {
		if(socket==null)
			return;
		try
		{
			BufferedOutputStream bOut = new BufferedOutputStream(socket.getOutputStream());
			PrintWriter out=new PrintWriter(bOut,true);
			out.println(text);
		}catch(IOException e)
		{
			area.append("Connection Error: "+e.getMessage()+System.lineSeparator());
		}
		
		
	}

	@Override
	public void run() {
		if(socket==null)
			return;
		try {
				BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream()));
				while(!Thread.currentThread().isInterrupted())
				{
					if(in.ready())
					{
						area.append("Server wrote: "+in.readLine()+System.lineSeparator());
					}
				}
		} catch (IOException e) {e.printStackTrace();}
		
	}

}
