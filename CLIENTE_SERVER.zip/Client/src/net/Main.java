package net;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Main {

	public static void main(String[] args) throws UnknownHostException, IOException 
	{
		JFrame f=new JFrame("Client");
		f.setSize(400,400);
		JPanel p=new JPanel();
		p.setLayout(new GridLayout(3,1));
		JButton startServer=new JButton("Send message");
		JTextArea area=new JTextArea();
		JTextArea myMessages=new JTextArea();
		Client c=new Client(area);
		c.startClient();
		area.setEditable(false);
		startServer.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				c.sendMessage(myMessages.getText());
				myMessages.setText("");
				
			}
		});
		p.add(startServer);
		p.add(new JScrollPane(area));
		p.add(new JScrollPane(myMessages));
		f.add(p);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		

	}

}
