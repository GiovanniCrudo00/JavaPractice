package net;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JTextArea;

public class MessagesHandler implements Runnable{
	private Socket socket;
	private JTextArea area;

	public MessagesHandler(Socket socket, JTextArea area) {
		this.socket=socket;
		this.area=area;
	}

	@Override
	public void run() {
		//Qui gestiamo le comunicazioni
		try 
		{
			BufferedOutputStream bOut=new BufferedOutputStream(socket.getOutputStream());
			PrintWriter out=new PrintWriter(bOut,true);
			out.println("Welcome...");
			BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream()));
			while(!Thread.currentThread().isInterrupted())
			{
				if(in.ready())
				{
					String line=in.readLine();
					area.append("Client wrote: "+line+System.lineSeparator());
					if(line.equals("ciao"))
						out.println("ciao a te");
					else if(line.equals("come stai?"))
						out.println("bene, tu?");
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
