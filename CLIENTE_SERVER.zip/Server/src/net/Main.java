package net;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Main {

	public static void main(String[] args) 
	{
		JFrame f=new JFrame("Server");
		f.setSize(400,400);
		JPanel p=new JPanel();
		p.setLayout(new GridLayout(2,1));
		JButton startServer=new JButton("Start Server");
		JTextArea area=new JTextArea();
		startServer.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				Server server=new Server(area);
				server.startServer();
				startServer.setEnabled(false);
				
			}
		});
		p.add(startServer);
		p.add(new JScrollPane(area));
		f.add(p);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		

	}

}
