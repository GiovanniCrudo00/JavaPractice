package net;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.JTextArea;

public class Server implements Runnable{
	
	private JTextArea area;
	private ServerSocket server;
	private ExecutorService executor;
	public Server(JTextArea area)
	{
		this.area=area;
		executor=Executors.newCachedThreadPool();
	}

	public void startServer() {
		try 
		{
			server= new ServerSocket(8000);
			Thread t=new Thread(this);
			t.start();
		}catch (IOException e) {area.append("Error while starting the server: "+e.getMessage()+System.lineSeparator());}
	}

	@Override
	public void run() {
		while(!Thread.currentThread().isInterrupted())
		{
			try
			{
				area.append("Waiting for new connections"+System.lineSeparator());
				Socket socket=server.accept();
				area.append("Client Connected..."+System.lineSeparator());
				MessagesHandler handler=new MessagesHandler(socket,area);
				executor.submit(handler); //server per allocare ogni volta un nuovo thread
			}
				catch(IOException e){area.append("Connection Error"+e.getMessage()+System.lineSeparator());
				return;
			}
		}
	}

}
