package Controllers;

import Application.SceneHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.AnchorPane;

public class TLMainPage_Controller {

    @FXML
    private MenuButton Projects_Toolbar;

    @FXML
    private AnchorPane root_TLMainPage;

    @FXML
    private ToggleButton Dark_mode;

    @FXML
    private MenuButton Tickets_Toolbar;

    @FXML
    private MenuButton Charts_Toolbar;

    @FXML
    private ToolBar TeamLeader_Toolbar;

    @FXML
    private MenuButton Users_Toolbar;

    @FXML
    private Button Logout_button;

    @FXML
    private MenuButton Admins_Toolbar;

    @FXML
    void Set_Dark(ActionEvent event) {
    	if (Dark_mode.isSelected()) {
    		root_TLMainPage.setStyle("-fx-base:black");
    		Dark_mode_reference.isDark=true;
    	}
    	else {
    		root_TLMainPage.setStyle("");
    		Dark_mode_reference.isDark=false;
    	}
    }
@FXML
   private void initialize() {
	if (Dark_mode_reference.isDark) {
		root_TLMainPage.setStyle("-fx-base:black");
		Dark_mode.setSelected(true);
	}
   }

	@FXML
	void Logout(ActionEvent event) throws Exception {
			SceneHandler.getInstance().setLoginScene();
	}

    @FXML
    void Show_Projects(ActionEvent event) {
    		Projects_Toolbar.getItems();
    }

    @FXML
    void Show_Tickets(ActionEvent event) {

    }

    @FXML
    void Show_Users(ActionEvent event) {

    }

    @FXML
    void Show_Admins(ActionEvent event) {

    }

    @FXML
    void Show_Charts(ActionEvent event) {

    }

}
