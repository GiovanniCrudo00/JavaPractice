package Application;

import java.io.File;
import java.util.ArrayList;

public class Ticket {
	//-----------------------------------------------
	//attributi
	private String ID;
	private String name;
	private int Priority;
	private ArrayList <String> LinkedTickets;
	private ArrayList <String> Keywords;
	private String Description;
	private File solution;
	//--------------------------------------------------------------------
	//metodi
	public String getID() {return ID;}
	public void setID(String iD) {ID = iD;}
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public int getPriority() {return Priority;}
	public void setPriority(int priority) {Priority = priority;}
	public ArrayList<String> getLinkedTickets() {return LinkedTickets;}
	public void setLinkedTickets(ArrayList<String> linkedTickets) {LinkedTickets = linkedTickets;}
	public ArrayList<String> getKeywords() {return Keywords;}
	public void setKeywords(ArrayList<String> keywords) {Keywords = keywords;}
	public String getDescription() {return Description;}
	public void setDescription(String description) {Description = description;}
	public File getSolution() {return solution;}
	public void setSolution(File solution) {this.solution = solution;}
	public Ticket() {
		 ID="";
		 name="";
		 Priority=-1;
		 LinkedTickets=new ArrayList<String>();
		 Keywords=new ArrayList<String>();
		 Description="";
		 solution=null;
	}
	

}
