package Application;
import java.util.ArrayList;

public class Project {
	private String Nome;
	private ArrayList<String> TypeofIssues;
	private ArrayList<String> Users; 
	private ArrayList<String> Admin;
	String a;
	public Project(){
		
		this.Nome=" ";
		this.TypeofIssues=new ArrayList<String>();
		this.Users=new ArrayList<String>();
		this.Admin=new ArrayList<String>();
	}
	@SuppressWarnings("unchecked")
	public Project(String N,ArrayList<String> TOI,ArrayList<String> U,ArrayList<String> A){
		this.Nome=N;
		this.TypeofIssues=(ArrayList<String>) TOI.clone();
		this.Users=(ArrayList<String>) U.clone();
		this.Admin=(ArrayList<String>) A.clone();
	}
	public void addTypeOfIssue(String issue) {TypeofIssues.add(issue);}
	public void addUsers(String user) {Users.add(user);}
	public void addAdmins(String admin) {Users.add(admin);}
	public void setNome(String nome) {this.Nome=nome;}
	public String getNome() {return this.Nome;}
	public ArrayList<String> getIssues() {return this.TypeofIssues;}
	public ArrayList<String> getUsers(){return this.Users;}
	public ArrayList<String> getAdmins(){return this.Admin;}
		

}
