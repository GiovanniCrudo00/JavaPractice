package Esercizio1;

public class Thread1 extends Thread
{	
	@Override
	public void run()
	{
		super.run();
	}
	public double calcola(int n1, int n2)
	{
		return n1+n2;
	}
}