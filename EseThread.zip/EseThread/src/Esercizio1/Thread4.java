package Esercizio1;

public class Thread4 extends Thread
{
	@Override
	public void run()
	{
		super.run();
	}
	public double calcola(int nu1, int nu2)
	{
		double n1=(double) nu1;
		double n2=(double) nu2;
		return n1/n2;
	}
}
