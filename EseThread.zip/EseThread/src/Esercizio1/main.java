package Esercizio1;

import java.util.Scanner;

public class main 
{
	private static char estraiOperatore(String str)
	{
		char op = 0;
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='+') op='+'; //t1
			else if(str.charAt(i)=='x') op='x'; //t2
			else if(str.charAt(i)=='-') op='-'; //t3
			else if(str.charAt(i)=='/') op='/'; //t4
			else;
		}
		return op;
	}
	private static int estraiNumero1(String str, char op)
	{
		String nu="";
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)==op) break;
			else nu+=str.charAt(i);
		}
		return Integer.parseInt(nu);
	}
	private static int estraiNumero2(String str, char op)
	{
		String nu="";
		int c=0;
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)==op) c=i;
		}
		for(int i=c+1;i<str.length();i++)
		{
			nu+=str.charAt(i);
		}
		return Integer.parseInt(nu);
	}
	private static double calcola(int n1,int n2,char op)
	{
		double res=0.00;
		if(op=='+')
		{
			Thread1 t1=new Thread1();
			t1.start();
			res=t1.calcola(n1,n2);
		}
		else if(op=='x')
		{
			Thread2 t2=new Thread2();
			t2.start();
			res=t2.calcola(n1,n2);
		}
		else if(op=='-')
		{
			Thread3 t3=new Thread3();
			t3.start();
			res=t3.calcola(n1,n2);
		}
		else if(op=='/')
		{
			Thread4 t4=new Thread4();
			t4.start();
			res=t4.calcola(n1,n2);
		}
		else;
		return res;
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Inserisci operazione");
		String str=sc.next();
		char op=estraiOperatore(str);
		int n1=estraiNumero1(str,op);
		int n2=estraiNumero2(str,op);
		System.out.println("= "+calcola(n1,n2,op));
		
	}
}
