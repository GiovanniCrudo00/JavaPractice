package Application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.security.crypto.bcrypt.BCrypt;

public class Database {
	
	public static void insertUsers(String Username,String Password,String Nome,String Cognome,String Email) {
		Connection con=DbConnection.connect();
		PreparedStatement ps=null;
		try {
			String PasswordCrypted=CryptPass(Password);
			String sql="INSERT INTO users (Username,Password,Nome,Cognome,Email) VALUES(?,?,?,?,?) ";
			ps = con.prepareStatement(sql);
			ps.setString(1, Username);
			ps.setString(2, PasswordCrypted);
			ps.setString(3, Nome);
			ps.setString(4, Cognome);
			ps.setString(5, Email);
			ps.execute();
			ps.close();
			System.out.println("Utente aggiunto!");
		}
		catch(SQLException e){System.out.println(e.toString());}
	}
	public static void deleteAll() {
		Connection con=DbConnection.connect();
		PreparedStatement ps=null;
		try {
			String sql="DELETE FROM users";
			ps = con.prepareStatement(sql);
			ps.execute();
			ps.close();
			System.out.println("Tabella Cancellata");
		}
		catch(SQLException e){System.out.println(e.toString());}
	}
	public static String CryptPass(String originalPassword) {
		 String Crypted= BCrypt.hashpw(originalPassword, BCrypt.gensalt(12));
		 return Crypted;		
	}
	public static Boolean userExists(String user) throws SQLException {
		String sql = "SELECT * FROM Users WHERE Username=? ;";
		Connection con=DbConnection.connect();
		PreparedStatement ps=null;
		ps=con.prepareStatement(sql);
		ps.setString(1, user);
		ResultSet rs= ps.executeQuery();
		if(!rs.next()) {
			ps.close();
			return false;
		}
		ps.close();
		return true;
	}
		public static Boolean Checkuser(String user,String Pass) throws SQLException {
			String sql = "SELECT * FROM users WHERE Username=? ;";
			Connection con=DbConnection.connect();
			PreparedStatement ps=null;
			ps=con.prepareStatement(sql);
			ps.setString(1, user);
			ResultSet rs= ps.executeQuery();
			while(rs.next()) {
				if ( BCrypt.checkpw(Pass,rs.getString("Password"))) {
					ps.close();
					return true;
				}
				
			}
			ps.close();
			return false;
	}
}
