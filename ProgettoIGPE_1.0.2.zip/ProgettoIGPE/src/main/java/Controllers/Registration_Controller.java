package Controllers;

import java.sql.SQLException;
import java.util.regex.Pattern;

import Application.Database;
import Application.SceneHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;

public class Registration_Controller {
	@FXML
    private PasswordField textAreaPass2;

    @FXML
    private Label labelCognome;

    @FXML
    private PasswordField textAreaPass1;

    @FXML
    private TextField textAreaNome;

    @FXML
    private TextField textAreaCognome;

    @FXML
    private AnchorPane root_Registration;

    @FXML
    private Button buttonRegistrati;

    @FXML
    private ToggleButton Dark_mode;

    @FXML
    private Label labelNome;

    @FXML
    private TextField textAreaUsername;

    @FXML
    private Button backToHome;

    @FXML
    private TextField textAreaEmail;

    @FXML
    private Label labelUsername;

    @FXML
    private Label labelEmail;

    @FXML
    private Label labelPass1;

    @FXML
    private Label labelPass2;

    @FXML
    void BackHome(ActionEvent event) throws Exception {
    	SceneHandler.getInstance().setLoginScene();
    }

    @FXML
    void registraUtente(ActionEvent event) throws SQLException {
    	if (textAreaUsername.getText().isBlank() || textAreaPass1.getText().isBlank() || textAreaNome.getText().isBlank() || textAreaCognome.getText().isBlank() || textAreaEmail.getText().isBlank()) {
    		Alert errorAlert = new Alert(AlertType.ERROR);
    		errorAlert.setHeaderText("Si Prega di riempire tutti i campi");
    		errorAlert.setContentText("Alcuni campi sono vuoti");
    		errorAlert.showAndWait();
    		return;
    	}
    	if (Database.userExists(textAreaUsername.getText())) {Alert errorAlert = new Alert(AlertType.ERROR);
		errorAlert.setHeaderText("Username Gi� esistente");
		errorAlert.setContentText("scegliere un altro username");
		errorAlert.showAndWait();
		return;
    	}
    	if (textAreaUsername.getText().contains(" ")) {
    		Alert errorAlert = new Alert(AlertType.ERROR);
    		errorAlert.setHeaderText("Username non valido");
    		errorAlert.setContentText("Inserire Username senza spazi");
    		errorAlert.showAndWait();
    		return;
    		
    	}
    	if (Pattern.matches( "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%_^&+=])(?=\\S+$).{8,}$", textAreaPass1.getText())) {
	    	if(!(textAreaPass1.getText().matches(textAreaPass2.getText()))) {
	    		Alert errorAlert = new Alert(AlertType.ERROR);
	    		errorAlert.setHeaderText("Le due password non coincidono");
	    		errorAlert.setContentText("Prova a riscrivere una delle due");
	    		errorAlert.showAndWait();
	    		return;
	    	}
    	}
    	else {
    		Alert errorAlert = new Alert(AlertType.ERROR);
    		errorAlert.setHeaderText("Password non valida");
    		errorAlert.setContentText("la Password deve contenere almeno un numero,una lettera maiuscola,una minuscola e un carattere speciale");
    		errorAlert.showAndWait();	
    		return;
    	}
    	if (!(Pattern.matches( "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\."
    			+ "[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\"
    			+ "x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\"
    			+ "[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])"
    			+ "?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"
    			+ "\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b"
    			+ "\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])" , textAreaEmail.getText()))) {
    		Alert errorAlert = new Alert(AlertType.ERROR);
    		errorAlert.setHeaderText("Email non valida");
    		errorAlert.setContentText("Inserire una Email valida");
    		errorAlert.showAndWait();	
    		return;	
    	}
   	SendMail.Send_mail(textAreaEmail.getText(), textAreaNome.getText(), textAreaCognome.getText(), textAreaUsername.getText());
    	Alert errorAlert = new Alert(AlertType.INFORMATION);
		errorAlert.setHeaderText("Registrazione avvenuta con successo");
		errorAlert.setContentText("Le abbiamo inviato una Mail di Benvenuto");
		errorAlert.showAndWait();	
		Database.insertUsers(textAreaUsername.getText(), textAreaPass1.getText(), textAreaNome.getText(), textAreaCognome.getText(), textAreaEmail.getText());
    }

    @FXML
    void Set_Dark(ActionEvent event) {
    	if (Dark_mode.isSelected()) {
    		root_Registration.setStyle("-fx-base:black");
    		Dark_mode_reference.isDark=true;
    	}
    	else {
    		root_Registration.setStyle("");
    		Dark_mode_reference.isDark=false;
    	}
    }
@FXML
   private void initialize() {
	if (Dark_mode_reference.isDark) {
		root_Registration.setStyle("-fx-base:black");
		Dark_mode.setSelected(true);
	}
   }
   }
