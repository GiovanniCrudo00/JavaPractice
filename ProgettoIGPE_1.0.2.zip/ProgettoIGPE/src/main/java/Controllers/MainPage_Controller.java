package Controllers;

import Application.SceneHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.AnchorPane;

public class MainPage_Controller {

    @FXML
    private AnchorPane root_MainPage;

    @FXML
    private ToggleButton Dark_mode;

    @FXML
    private Button Account_Button;

    @FXML
    private Button Logout_button;

    @FXML
    void Set_Dark(ActionEvent event) {
    	if (Dark_mode.isSelected()) {
    		root_MainPage.setStyle("-fx-base:black");
    		Dark_mode_reference.isDark=true;
    	}
    	else {
    		root_MainPage.setStyle("");
    		Dark_mode_reference.isDark=false;
    	}
    }
@FXML
   private void initialize() {
	if (Dark_mode_reference.isDark) {
		root_MainPage.setStyle("-fx-base:black");
		Dark_mode.setSelected(true);
	}
   }	

    @FXML
    void Set_account_page(ActionEvent event) {
    	
    }
    @FXML
    void Logout(ActionEvent event) throws Exception {
    		SceneHandler.getInstance().setLoginScene();
    }

}