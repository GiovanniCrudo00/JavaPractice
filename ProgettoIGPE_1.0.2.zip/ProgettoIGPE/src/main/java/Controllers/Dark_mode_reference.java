package Controllers;
public class Dark_mode_reference{
	public static boolean isDark=false;
	public static  boolean getisDark() {
		return isDark;
	}
}
