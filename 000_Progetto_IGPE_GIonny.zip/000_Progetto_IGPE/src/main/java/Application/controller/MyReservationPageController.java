package Application.controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import Application.app.SceneHandler;
import Application.logic.Reservations;
import Application.net.Client;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MyReservationPageController {
	public static Reservations res = null;
	 @FXML
	 private VBox vbox;
	 
	 @FXML
	 private Label home;
	 
	 @FXML
	 private Label logOut;
	 
	 @FXML 
	 public void initialize() {
		 try {
			 for(int i = 0; i < res.reservations.size(); ++i) {
				 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
				  LocalDateTime now = LocalDateTime.now();  
				  String data = res.reservations.get(i).getData();
				  String[] datas = data.split("-");
				  if(now.getYear() <= Integer.parseInt(datas[0]) && now.getMonthValue() <= Integer.parseInt(datas[1]) && now.getDayOfMonth() <= Integer.parseInt(datas[2]))
				 vbox.getChildren().add(SceneHandler.getInstance().getReservationCard(i, res));
			 }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 
	 @FXML
	    void goHome(MouseEvent event) {
		 try {
				SceneHandler.getInstance().setCustomerDashboard();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	 
	 @FXML
	    void logout(MouseEvent event) {
		 try {
				Stage stage = (Stage) logOut.getScene().getWindow();
			    stage.close();
				Client.getInstance().closeConnections();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	

}
