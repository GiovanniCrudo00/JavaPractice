package Application.controller;

import java.io.IOException;

import Application.app.SceneHandler;
import Application.net.Client;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class FetchPasswordController {
	  @FXML
	    private ImageView backbutton;

	    @FXML
	    private Button fetchPasswordButton;

	    @FXML
	    private TextField emailField;

	
	 @FXML
	 void goBack(MouseEvent event) {
		 try {
			SceneHandler.getInstance().setLoginScene();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 
	 
	 @FXML
	 void fetchPasswordCode(MouseEvent event) {
		 String email = emailField.getText();
		 try {
			Client.getInstance().fetchPassword(email);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
}
