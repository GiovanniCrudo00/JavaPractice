package Application.controller;

import Application.app.SceneHandler;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

public class RegistrationController {

	    @FXML
	    private VBox staffChoose;

	    @FXML
	    private ImageView backbutton;

	    @FXML
	    private VBox customerChoose;

	    @FXML
	    void goBack(MouseEvent event) {
	    	try {
				SceneHandler.getInstance().setLoginScene();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void staffRegistration(MouseEvent event) {
	    	try {
				SceneHandler.getInstance().setShopRegistrationScene();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

	    @FXML
	    void customerRegistration(MouseEvent event) {
	    	try {
				SceneHandler.getInstance().setCustomerRegistrationScene();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

}


