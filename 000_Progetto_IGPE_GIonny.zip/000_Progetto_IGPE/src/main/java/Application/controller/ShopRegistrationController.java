package Application.controller;

import java.io.IOException;

import org.springframework.security.crypto.bcrypt.BCrypt;

import Application.app.SceneHandler;
import Application.net.Client;
import Application.net.common.Place;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class ShopRegistrationController {
	@FXML
    private TextField startTimeField;

    @FXML
    private TextField shopNameField;

    @FXML
    private TextField cityField;

    @FXML
    private ImageView backbutton;

    @FXML
    private TextField endTimeField;

    @FXML
    private Button registerButton;

    @FXML
    private TextField addressNumberField;

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField addressField;

    @FXML
    private TextField capFied;

	@FXML
    void goBack(MouseEvent event) {
    	try {
			SceneHandler.getInstance().setRegistrationScene();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	
	@FXML
    void registerShop(MouseEvent event) {
		String[] start = startTimeField.getText().split(":");
		String[] end   = endTimeField.getText().split(":");
		try {
			if(Integer.parseInt(start[0]) > 23    || Integer.parseInt(start[0]) < 0 ||
			   Integer.parseInt(start[1]) > 59    || Integer.parseInt(start[1]) < 0 ||
			   Integer.parseInt(end[0]  ) > 23    || Integer.parseInt(end[0])   < 0 ||
			   Integer.parseInt(end[0]  ) > 59    || Integer.parseInt(end[1])   < 0) {
				SceneHandler.getInstance().showError("Attenzione! L'orario deve essere espresso in formaro xx:yy" + System.lineSeparator() + "Esempio : 23:30");
				return;
			}
		}catch (Exception e) {
			SceneHandler.getInstance().showError("Attenzione! L'orario deve essere espresso in formaro xx:yy");
			return;
		}
		int cap = -1;
		try {
			cap = Integer.parseInt(capFied.getText());
		}catch (Exception e) {
			SceneHandler.getInstance().showError("Attenzione! Il cap è un numero formato da 5 cifre");
			return;
		}
		if(capFied.getText().toString().length() != 5 || cap > 99999 || cap < 0) {
			SceneHandler.getInstance().showError("Attenzione! Il CAP é un numero formato da 5 cifre.");
			return;
		}
		String password = BCrypt.hashpw(passwordField.getText(), BCrypt.gensalt(12));
		Place p = new Place(shopNameField.getText(), null, startTimeField.getText(), endTimeField.getText(),
							cityField.getText(), capFied.getText(), addressField.getText(), addressNumberField.getText(), 
							password, emailField.getText());
		try {
			Client.getInstance().ShopRegistrationProcedure(p);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
