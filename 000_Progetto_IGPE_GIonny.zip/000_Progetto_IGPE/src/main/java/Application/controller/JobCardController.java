package Application.controller;

import Application.logic.ReservationHandler;
import Application.net.Client;
import Application.net.common.Jobs;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class JobCardController {
	public static Jobs j;
	private Integer contatore = 0;
	public static Integer i = 0;
	
	@FXML
    private Label jobName;

    @FXML
    private Label duration;

    @FXML
    private ImageView add;

    @FXML
    private Label price;

    @FXML
    private Label cont;

    @FXML
    private ImageView remove;
    
    @FXML 
    private Label index;
    
    @FXML
    public void initialize() {
    	if(j != null) {
	    	index.setText(i.toString());
	    	jobName.setText(j.jobs.get(Integer.parseInt(index.getText())).getNomePrestazione());
	    	duration.setText(j.jobs.get(Integer.parseInt(index.getText())).getTempoEsecuzione() + " minuti");
	    	price.setText(j.jobs.get(Integer.parseInt(index.getText())).getCosto() + "€");
	    	cont.setVisible(false);
	    	ReservationHandler.getInstance().setReservation(Client.getInstance().getUser(), j.jobs.get(Integer.parseInt(index.getText())).getPlaceName());
    	}
    }
    
    @FXML
    void add(MouseEvent event) {
    	cont.setVisible(true);
    	contatore++;
    	cont.setText(contatore.toString());
    	ReservationHandler.getInstance().getReservation().addJob(j.jobs.get(Integer.parseInt(index.getText())));
    	System.out.println("[AGGIUNTO]" + ReservationHandler.getInstance().getReservation().getJobs().jobs.toString());
    }

    @FXML
    void remove(MouseEvent event) {
    	if(contatore == 0) { 
    		return;
    	}
    	else {
    		contatore--;
    		if(contatore == 0)cont.setVisible(false);
    		cont.setText(contatore.toString());
    		ReservationHandler.getInstance().getReservation().removeJob(j.jobs.get(Integer.parseInt(index.getText())));
    		System.out.println("[RIMOSSO]" + ReservationHandler.getInstance().getReservation().getJobs().jobs.toString());
    	}
    	
    }
    
    

}
