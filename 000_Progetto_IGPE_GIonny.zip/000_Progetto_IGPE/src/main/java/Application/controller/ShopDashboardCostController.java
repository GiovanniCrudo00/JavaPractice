package Application.controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import Application.app.SceneHandler;
import Application.logic.Cost;
import Application.net.Client;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class ShopDashboardCostController {
	@FXML
    private Label notices;

    @FXML
    private BarChart<String, Number> barchart;

    @FXML
    private Label cost;

    @FXML
    private Label logOut;

    @FXML
    private Label home;
    
    @FXML
    private TextField motivoField;
    
    @FXML
    private TextField costField;
    
    @FXML
    private Button addButton;
    
    @FXML
    private ImageView refresh;

    @FXML
    public void initialize() {
          XYChart.Series<String, Number> profitti = new XYChart.Series<String, Number>();
          profitti.setName("Profitti");
          profitti.getData().add(new XYChart.Data<String, Number>("Profitti", Client.getInstance().getProfitti(Client.getInstance().getPlace().getNomeNegozio())));
          barchart.getData().add(profitti);
          
          XYChart.Series<String, Number> costi = new XYChart.Series<String, Number>();
          costi.setName("Costi");
          costi.getData().add(new XYChart.Data<String, Number>("Profitti", Client.getInstance().getCosti(Client.getInstance().getPlace().getNomeNegozio())));
          barchart.getData().add(costi);
          
        //set first bar color
          for(Node n:barchart.lookupAll(".default-color0.chart-bar")) {
                    n.setStyle("-fx-bar-fill: #43aa8b;");
               }
        //second bar color
          for(Node n:barchart.lookupAll(".default-color1.chart-bar")) {
                    n.setStyle("-fx-bar-fill: #ff6b6b;");
               }
    }
    
    @FXML
    void addCost(MouseEvent event) {
    	String motivo = motivoField.getText();
    	String costo = costField.getText();
    	String shop = Client.getInstance().getPlace().getNomeNegozio();
    	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
    	LocalDateTime now = LocalDateTime.now();  
    	Cost cost = new Cost(shop, motivo, costo, now.getYear() + "-" + now.getMonthValue() + "-" + now.getDayOfMonth());
    	Client.getInstance().addCosto(cost);
    	motivoField.setText("");
    	costField.setText("");
    }
    
    @FXML
    void refresh(MouseEvent event) {
    	try {
			SceneHandler.getInstance().setShopDashboardCost();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void goHome(MouseEvent event) {
    	try {
			SceneHandler.getInstance().setShopDashboardHome();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @FXML
    void goNotices(MouseEvent event) {
    	try {
			SceneHandler.getInstance().setShopDashboard();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void goCost(MouseEvent event) {
    	try {
			SceneHandler.getInstance().setShopDashboardCost();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void logout(MouseEvent event) {
    	 try {
				Stage stage = (Stage) logOut.getScene().getWindow();
			    stage.close();
				Client.getInstance().closeConnections();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    }

}
