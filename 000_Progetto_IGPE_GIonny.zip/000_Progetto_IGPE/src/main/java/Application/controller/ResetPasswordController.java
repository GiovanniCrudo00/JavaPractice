package Application.controller;

import java.io.IOException;

import org.springframework.security.crypto.bcrypt.BCrypt;

import Application.app.SceneHandler;
import Application.net.Client;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class ResetPasswordController {
	@FXML
    private Button resetPasswordButton;

    @FXML
    private ImageView backbutton;

    @FXML
    private PasswordField passwordField;

    @FXML
    void goBack(MouseEvent event) {
    	try {
			SceneHandler.getInstance().setLoginScene();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void resetPasswordCode(MouseEvent event) {
    	String newPassword = BCrypt.hashpw(passwordField.getText(), BCrypt.gensalt(12));
    	try {
			Client.getInstance().resetPassword(newPassword);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

}
