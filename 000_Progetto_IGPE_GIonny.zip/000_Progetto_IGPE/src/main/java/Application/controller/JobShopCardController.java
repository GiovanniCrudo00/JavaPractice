package Application.controller;

import java.io.IOException;

import Application.app.SceneHandler;
import Application.net.Client;
import Application.net.common.Jobs;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

public class JobShopCardController {
	
	public static Jobs j;
	public static Integer i;
	@FXML
    private Label jobName;

    @FXML
    private Label duration;

    @FXML
    private Label price;

    @FXML
    private Label modifica;

    @FXML
    private Label index;

    @FXML
    private Label elimina;
    
    @FXML
    public void initialize() {
    	index.setText(i.toString());
    	jobName.setText(j.jobs.get(Integer.parseInt(index.getText())).getNomePrestazione());
    	duration.setText(j.jobs.get(Integer.parseInt(index.getText())).getTempoEsecuzione() + " minuti");
    	price.setText(j.jobs.get(Integer.parseInt(index.getText())).getCosto() + "€");
    }

    
    @FXML
    void modificaJob(MouseEvent event) {
    	try {
			SceneHandler.getInstance().initModifyJobDialog(j, Integer.parseInt(index.getText()));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void eliminaJob(MouseEvent event) {
    	Client.getInstance().deleteJob(j.jobs.get(Integer.parseInt(index.getText())));
    	try {
			SceneHandler.getInstance().setShopDashboardHome();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

}
