package Application.controller;

import java.io.IOException;

import Application.app.SceneHandler;
import Application.logic.Reservations;
import Application.net.Client;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class ReservationShopCardController {
	public static Reservations res = null;
	public static Integer i = 0;
	
	  @FXML
	    private Label Username;

	    @FXML
	    private Label totale;

	    @FXML
	    private Label accetta;
	    
	    @FXML
	    private Label rifiuta;

	    @FXML
	    private Label index;

	    @FXML
	    private ImageView info;

	    @FXML
	    private void initialize() {
	    	this.index.setText(i.toString());
	    	Username.setText(res.reservations.get(Integer.parseInt(index.getText())).getNegozio());
	    	Integer totale = 0;
	    	for(int i = 0; i < res.reservations.get(Integer.parseInt(index.getText())).getJobs().jobs.size(); ++i)
	    		totale += Integer.parseInt(res.reservations.get(Integer.parseInt(index.getText())).getJobs().jobs.get(i).getCosto());
	    	this.totale.setText("Tot : " + totale.toString() + "€");
		}
	    @FXML
	    void openDialog(MouseEvent event) {
	    	int j = Integer.parseInt(index.getText());
	    	StringBuilder builder = new StringBuilder();
	    	for(int i = 0; i < res.reservations.get(j).getJobs().jobs.size(); ++i)
	    		builder.append( res.reservations.get(j).getJobs().jobs.get(i).getNomePrestazione() + " " +  res.reservations.get(j).getJobs().jobs.get(i).getCosto() + "€\n");
	    	builder.append("Data : " + res.reservations.get(j).getData() + "\nOra : "  + res.reservations.get(j).getOra());
	    	SceneHandler.getInstance().showDialog(builder.toString());
	    }
	    
	    @FXML
	    void accetta(MouseEvent event) {
	    	int j = Integer.parseInt(index.getText());
	    	
	    	if(Client.getInstance().acceptReservation(res.reservations.get(j))) {
	    		res.reservations.remove(j);
				try {
					SceneHandler.getInstance().setShopDashboard();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    	}
	    }
	    
	    @FXML
	    void rifiuta(MouseEvent event) {
	    	int j = Integer.parseInt(index.getText());
	    	try {
				if(Client.getInstance().removeReservation(res.reservations.get(j))) {
					res.reservations.remove(j);
					try {
						SceneHandler.getInstance().setShopDashboard();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }


}
