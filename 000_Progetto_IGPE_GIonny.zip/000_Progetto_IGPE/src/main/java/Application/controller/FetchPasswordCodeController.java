package Application.controller;

import java.io.IOException;

import Application.app.SceneHandler;
import Application.net.Client;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class FetchPasswordCodeController {
	  @FXML
	    private TextField codeField;

	    @FXML
	    private ImageView backbutton;

	    @FXML
	    private Button nextPageButton;

	    @FXML
	    void goBack(MouseEvent event) {
	    	try {
				SceneHandler.getInstance().setFetchPasswordScene();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    @FXML
	    void goInsertNewPassword(MouseEvent event) {
	    	try {
				Client.getInstance().checkCode(codeField.getText());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }


}
