package Application.controller;

import java.io.IOException;

import Application.app.SceneHandler;
import Application.logic.Reservations;
import Application.net.Client;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ShopDashboardController {
	
	private Reservations reservations;
	 @FXML
	    private Label notices;

	    @FXML
	    private VBox scrollVBox;

	    @FXML
	    private Label cost;

	    @FXML
	    private ScrollPane scrollPane;

	    @FXML
	    private Label logOut;

	    @FXML
	    private Label home;
	    
	    @FXML
	    private HBox hbox;
	    @FXML
	    private ImageView image;
	    @FXML
	    private Label label;
	    
	    @FXML
	   public void initialize() {
	    	try {
				reservations = Client.getInstance().getReservations(Client.getInstance().getPlace().getNomeNegozio(), true);
				for(int i = 0; i < reservations.reservations.size(); ++i) {
					if(reservations.reservations.get(i).getAccettato().equals("0"))
					scrollVBox.getChildren().add(SceneHandler.getInstance().getReservationShopCard(i, reservations));
				}
				if(scrollVBox.getChildren().size() != 0) {
						hbox.setVisible(false);
						image.setVisible(false);
						label.setVisible(false);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void goHome(MouseEvent event) {
	    	try {
				SceneHandler.getInstance().setShopDashboardHome();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void goCost(MouseEvent event) {
	    	try {
				SceneHandler.getInstance().setShopDashboardCost();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void logout(MouseEvent event) {
	    	 try {
					Stage stage = (Stage) logOut.getScene().getWindow();
				    stage.close();
					Client.getInstance().closeConnections();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    }
}
