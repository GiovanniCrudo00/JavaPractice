package Application.controller;

import Application.app.SceneHandler;
import Application.logic.Reservations;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

public class ReservationCardController {
	public static Reservations reservations = null;
	public static Integer i = 0;
	   @FXML
	    private Label totale;

	    @FXML
	    private Label index;

	    @FXML
	    private Label placeName;

	    @FXML
	    private ImageView info;
	    
	    @FXML
	    private Label accettato;
	    
	    @FXML
	    public void initialize() {
	    	index.setText(i.toString());
	    	int j = Integer.parseInt(index.getText());
	    	placeName.setText(reservations.reservations.get(j).getNegozio());
	    	Integer totale = 0;
	    	for(int i = 0; i < reservations.reservations.get(j).getJobs().jobs.size(); ++i)
	    		totale += Integer.parseInt(reservations.reservations.get(j).getJobs().jobs.get(i).getCosto());
	    	this.totale.setText("Tot : " + totale.toString() + "€");
	    	
	    	for(int i = 0; i < reservations.reservations.size(); ++i ) {
	    		System.out.println("[CLIENT] : " + reservations.reservations.get(i).toString());
	    	}
	    	if(!reservations.reservations.get(j).getAccettato().equals("1")) {
	    		System.out.println("IN ATTESA");
	    		accettato.setText("In attesa");
	    		accettato.setStyle("-fx-background-color: #ffe66d");
	    		accettato.setTextFill(Color.web("#1A535C"));
	    	}
	    }
	    
	    @FXML
	    void openDialog(MouseEvent event) {
	    	int j = Integer.parseInt(index.getText());
	    	StringBuilder builder = new StringBuilder();
	    	for(int i = 0; i < reservations.reservations.get(j).getJobs().jobs.size(); ++i)
	    		builder.append( reservations.reservations.get(j).getJobs().jobs.get(i).getNomePrestazione() + " " +  reservations.reservations.get(j).getJobs().jobs.get(i).getCosto() + "€\n");
	    	builder.append("Data : " + reservations.reservations.get(j).getData() + "\nOra : "  + reservations.reservations.get(j).getOra());
	    	SceneHandler.getInstance().showDialog(builder.toString());
	    }

}
