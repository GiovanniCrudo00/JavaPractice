package Application.controller;

import java.io.IOException;

import Application.app.SceneHandler;
import Application.net.Client;
import Application.net.common.Protocol;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class LoginController {
	@FXML
    private TextField usernamefield;

    @FXML
    private Label fetchpasswordbutton;

    @FXML
    private PasswordField passwordfield;

    @FXML
    private Button loginbutton;

    @FXML
    private Button signupbutton;
    
    @FXML
    void loginAction(ActionEvent event) {
    	String username = usernamefield.getText();
    	String password = passwordfield.getText();
    	Client.getInstance().sendMessage(Protocol.connectionRequest);
    	try {
			if(Client.getInstance().rcvMessage().equals(Protocol.connectionAccepted)) {
				Client.getInstance().loginAuthentication(username, password);
				usernamefield.setText("");
				passwordfield.setText("");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    

    @FXML
    void registerAction(ActionEvent event) {
    	try {
			SceneHandler.getInstance().setRegistrationScene();
		} catch (Exception e) {
			System.out.println("ERRORE");
			e.printStackTrace();
		}
    }
    
    
    @FXML
    void fetchPassword(MouseEvent event) {
    	try {
    		SceneHandler.getInstance().setFetchPasswordScene();
    	}catch(Exception e) {
    		System.out.println("ERRORE");
    		e.printStackTrace();
    	}
    }

}
