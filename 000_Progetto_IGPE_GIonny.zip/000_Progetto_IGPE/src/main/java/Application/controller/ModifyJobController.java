package Application.controller;

import java.io.IOException;

import Application.app.SceneHandler;
import Application.net.Client;
import Application.net.common.Jobs;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class ModifyJobController {
	public static Jobs j = null;
	public static Integer i = 0;
	@FXML
    private Label index;
	
	@FXML
    private Button Avanti;
    
    @FXML
    private TextField priceField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField durationField;
	
    @FXML
    public void initialize() {
    	nameField.setText(j.jobs.get(i).getNomePrestazione());
    	priceField.setText(j.jobs.get(i).getCosto());
    	durationField.setText(j.jobs.get(i).getTempoEsecuzione());
    }
   
    @FXML
    void modifyJob(MouseEvent event) {
    	String newName = nameField.getText();
    		if(newName.equals("")) newName = null;
    	String newDuration = durationField.getText();
    		if(newDuration.equals("")) newDuration = null;
    	String newPrice = priceField.getText();
    		if(newPrice.equals("")) newPrice = null;
    	Client.getInstance().updateJob(j.jobs.get(i), newName, newDuration, newPrice );
    	Stage stage = (Stage) Avanti.getScene().getWindow();
    	stage.close();
    	try {
			SceneHandler.getInstance().setShopDashboardHome();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

}
