package Application.controller;

import java.io.IOException;

import org.springframework.security.crypto.bcrypt.BCrypt;

import Application.app.SceneHandler;
import Application.net.Client;
import Application.net.common.User;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class CustomerRegistrationController {
	
	  @FXML
	    private TextField usernameField;

	    @FXML
	    private TextField cityField;

	    @FXML
	    private ImageView backbutton;

	    @FXML
	    private TextField addressNumberField;

	    @FXML
	    private TextField nameField;

	    @FXML
	    private TextField emailField;

	    @FXML
	    private TextField BMonthField;

	    @FXML
	    private TextField surnameField;

	    @FXML
	    private Button registerButton;

	    @FXML
	    private TextField BDayField;

	    @FXML
	    private TextField BYearField = new TextField();

	    @FXML
	    private PasswordField passwordField;

	    @FXML
	    private TextField addressField;


    @FXML
    void goBack(MouseEvent event) {
    	try {
			SceneHandler.getInstance().setRegistrationScene();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @FXML
    void registerUser(MouseEvent event) {
    	StringBuffer bday = new StringBuffer();
    	int year = 0, month = 0, day = 0;
    	try {
    		year = Integer.parseInt(BYearField.getText());
    		month = Integer.parseInt(BMonthField.getText());
    		day  = Integer.parseInt(BDayField.getText());
    	}catch (Exception e) {
    		System.out.println("ERROR");
			e.printStackTrace();
		}
    	if(year > 1900 && year < 2021 && month > 0 && month <= 12 && day > 0 && day <= 31) {
    		bday.append(year);
    		bday.append("/");
    		bday.append(month);
    		bday.append("/");
    		bday.append(day);
    	}else {
    		SceneHandler.getInstance().showError("Error parsing B-day");
    		return;
    	}
    	String password = BCrypt.hashpw(passwordField.getText(), BCrypt.gensalt(12));
    	User u = new User(nameField.getText(), surnameField.getText(),
    					  bday.toString(), addressField.getText(), addressNumberField.getText(), 
    					  cityField.getText(), emailField.getText(), usernameField.getText(), password);
    	try {
			Client.getInstance().customerRegistrationProcedure(u);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
