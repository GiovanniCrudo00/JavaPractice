package Application.controller;

import java.io.IOException;

import Application.app.SceneHandler;
import Application.net.Client;
import Application.net.common.Jobs;
import Application.net.common.Places;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

public class ShopPageController {
	public static Places p = null;
	private Jobs j = null;
	public static int index = 0;
	  @FXML
	  private VBox scrollVBox;

	  @FXML
	  private ImageView backButton;
	  
	  @FXML
	  private Label orario;

	  @FXML
	  private Label shopName;

	  @FXML
	  private Label via;
	  
	  @FXML
	  private Button avanti;

	  @FXML
	  void goBack(MouseEvent event) {
		  try {
			SceneHandler.getInstance().setCustomerDashboard();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
	  
	  
	  @FXML
	    void openDialog(MouseEvent event) {
		  	try {
				SceneHandler.getInstance().initReservationDialog(p.places.get(index));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  }
	 
	  
	  @FXML
		public void initialize() {
		  System.out.println(index);
		  shopName.setText(p.places.get(index).getNomeNegozio());
		  via.setText(p.places.get(index).getVia() + ", " + p.places.get(index).getNumeroCivico() + " " + p.places.get(index).getCitta());
		  orario.setText(p.places.get(index).getOrarioInizio() + " - " + p.places.get(index).getOrarioFine()); 
		  j = Client.getInstance().getJobs(p.places.get(index).getNomeNegozio());
		  	if(!j.jobs.isEmpty()) {
			  	for(int i = 0; i < j.jobs.size(); ++i) {
				  	try {
						Parent p = SceneHandler.getInstance().getJobCard(j, i);
						//passare nel metodo sopra ^ il job corrente(fare una cosa simile ai negozi)
						scrollVBox.getChildren().add(p);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			  		System.out.println("[JOB "+ i +"] NomePrestazione : " + j.jobs.get(i).getNomePrestazione() + ", Costo : " + j.jobs.get(i).getCosto() + ", Durata : " + j.jobs.get(i).getTempoEsecuzione() + " minuti");
			  	}
		  	}else System.out.println("Sembra non ci siano ancora jobs disponibili");
		  	
		  	
		  	
		  		
	  }
}
