package Application.controller;

import java.io.IOException;

import Application.app.SceneHandler;
import Application.net.common.Place;
import Application.net.common.Places;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

public class ShopCardController{
	
	public static Place p = null;
	public static Places places = null;
	public static Integer i = 0;
	 @FXML
	 private Label shopName;
	 
	 @FXML
	 private Label address;

	 @FXML
	 private Label city;
	 
	 @FXML
	 private AnchorPane card;
	 
	 @FXML
	 private Label index;

	 @FXML
	 void goToShopPage(MouseEvent event) {
		 System.out.println(index.getText());
		 System.out.println(places.places.toString());
		 try {
			SceneHandler.getInstance().setShopPage(Integer.parseInt(index.getText()), places);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }


	@FXML
	public void initialize() {
		shopName.setText(p.getNomeNegozio());
		address.setText(p.getVia() + " Numero : " + p.getNumeroCivico()); 
		city.setText(p.getCitta() + ", CAP : " + p.getCap());
		index.setText(i.toString());
	}
}
