package Application.controller;

import java.io.IOException;

import Application.app.SceneHandler;
import Application.logic.Job;
import Application.net.Client;
import Application.net.common.Jobs;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ShopDashboardHomeController {
	private Jobs j;
	@FXML
    private Label notices;

    @FXML
    private VBox vbox;

    @FXML
    private Label cost;

    @FXML
    private TextField jobPriceField;

    @FXML
    private TextField jobDurationField;

    @FXML
    private VBox addJob;

    @FXML
    private Label logOut;

    @FXML
    private Label home;

    @FXML
    private TextField jobNameField;
    
    @FXML
    private Label shopName;
    
    @FXML
    private Button add;
    
    @FXML
    public void initialize() {
    	
    	shopName.setText(Client.getInstance().getPlace().getNomeNegozio());
    	j = Client.getInstance().getJobs(Client.getInstance().getPlace().getNomeNegozio());
    	try {
			for(int i = 0; i < j.jobs.size(); ++i) {
				if(j.jobs.get(i).getEliminato().equals("0"))
				vbox.getChildren().add(SceneHandler.getInstance().getJobShobCard(j, i));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @FXML
    void goHome(MouseEvent event) {
    	
    }
    
    @FXML
    void goCost(MouseEvent event) {
    	try {
			SceneHandler.getInstance().setShopDashboardCost();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @FXML
    void logout(MouseEvent event) {
    	try {
			Stage stage = (Stage) logOut.getScene().getWindow();
		    stage.close();
			Client.getInstance().closeConnections();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @FXML
    void goNotices(MouseEvent event) {
    	try {
			SceneHandler.getInstance().setShopDashboard();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @FXML
    void addJob(MouseEvent event) {
    	String nome = jobNameField.getText();
    	String durata = jobDurationField.getText();
    	String prezzo = jobPriceField.getText();
    	if(nome.isEmpty() || durata.isEmpty() || prezzo.isEmpty()) {
    		SceneHandler.getInstance().showError("Tutti i campi devono essere compilati");
    		return;
    	}
    	Job j = new Job(nome, prezzo, durata, Client.getInstance().getPlace().getNomeNegozio(), "0");
    	Client.getInstance().addJob(j);
    	 jobNameField.setText("");
    	 jobDurationField.setText("");
    	 jobPriceField.setText("");
    	 try {
			SceneHandler.getInstance().setShopDashboardHome();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    

}
