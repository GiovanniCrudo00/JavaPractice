package Application.controller;

import java.io.IOException;
import java.time.LocalDate;

import Application.app.SceneHandler;
import Application.logic.ReservationHandler;
import Application.net.Client;
import Application.net.common.EmailSender;
import Application.net.common.Place;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class ReservationPageController {
	
		public static Place p;
		
		@FXML
	    private Button Avanti;

	    @FXML
	    private ComboBox<String> Ore;

	    @FXML
	    private ComboBox<String> Minuti;

	    @FXML
	    private DatePicker Data;
	    
	    @FXML
	    public void initialize() {
	    	
	    	Ore.getItems().removeAll(Ore.getItems());
	        Ore.getItems().addAll("00", "01", "02", "03", "04", "05", "06", "07", "08", "09",
					   "10", "11", "12", "13", "14", "15", "16", "17", "18", "19",
					   "20", "21", "22", "23");
	        Ore.getSelectionModel().select("09");
	        
	        Minuti.getItems().removeAll(Minuti.getItems());
	        Minuti.getItems().addAll("00", "05", "10", "15", "20", "25", "30", "35", "40", "45", "50",
					   "55");
	        Minuti.getSelectionModel().select("00");
	    }
	    
	    @FXML
	    void SendReservation(MouseEvent event) {
	    	String oraScelta = Ore.getValue();
	    	String minutoScelto = Minuti.getValue();
	    	LocalDate date = Data.getValue();
	    	System.out.println(date + "\n" + oraScelta + " : " + minutoScelto);
	    	ReservationHandler.getInstance().getReservation().setData(date.toString());
	    	ReservationHandler.getInstance().getReservation().setOra(oraScelta + " : " + minutoScelto);
	    	System.out.println(ReservationHandler.getInstance().toString());
	    	try {
				Client.getInstance().addReservation(ReservationHandler.getInstance().getReservation());
				Stage stage = (Stage) Avanti.getScene().getWindow();
		    	stage.close();
		    	
		    	try {
					SceneHandler.getInstance().setCustomerDashboard();
					SceneHandler.getInstance().showDialog("Prenotazione aggiunta correttamente");
					EmailSender sender = new EmailSender(Client.getInstance().getUser().getMail());
					sender.sendMessage("POKET, CONFERMA PRENOTAZIONE", "La prenotazione da lei effettuata è andata a buon fine.", true);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

}
