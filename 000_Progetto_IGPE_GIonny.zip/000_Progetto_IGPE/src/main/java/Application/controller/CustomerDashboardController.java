package Application.controller;

import java.io.IOException;

import Application.app.SceneHandler;
import Application.net.Client;
import Application.net.common.Places;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CustomerDashboardController{
	
	@FXML
    private ScrollPane scrollPane;
	
	@FXML
	private VBox scrollVBox;
	
	@FXML
	private Label logOut;
	
	 @FXML
	    private Label reservations;
	
	@FXML
    void initialize() {
		Parent p = null;
		Places places1 = Client.getInstance().getAllShops(Client.getInstance().getCity());
		//System.out.println(places1.places.get(0).getNomeNegozio());
		
		for(int i = 0; i < places1.places.size(); ++i) {
			try {
				p = SceneHandler.getInstance().getShopCard(places1.places.get(i), i, places1);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			scrollVBox.getChildren().add(p);
		}
    }
	
	 @FXML
	    void logout(MouseEvent event) {
			 try {
				Stage stage = (Stage) logOut.getScene().getWindow();
			    stage.close();
				Client.getInstance().closeConnections();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	
	 
	 @FXML
	    void goToReservations(MouseEvent event) {
		 try {
			SceneHandler.getInstance().setReservationsPage(Client.getInstance().getReservations(Client.getInstance().getUser().getUsername()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    }


}