package Application.net.server;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLException;

import Application.net.common.Protocol;
import Application.app.SceneHandler;
import Application.logic.Cost;
import Application.logic.Job;
import Application.logic.Reservation;
import Application.logic.Reservations;
import Application.net.common.EmailSender;
import Application.net.common.Jobs;
import Application.net.common.LoginUser;
import Application.net.common.Place;
import Application.net.common.Places;
import Application.net.common.User;

public class MessagesHandler implements Runnable{
	
	Socket client;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	private String fetchPasswordCode = null;
	private String mail = null;
	
	
	public MessagesHandler(Socket client) throws IOException {
		this.client = client;
		this.out = new ObjectOutputStream(client.getOutputStream());
	}
	public void writeMessage(Object message) {
		if(out == null) {
			return;
		}
		try {
			out.writeObject(message);
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private void closeStreams() throws IOException {
		if(out != null )
			out.close();
		out = null;
		if(in != null)
			in.close();
		in = null;
		if(client != null)
			client.close();
		client = null;
	}
	
	public void run() {
		try {
			this.in = new ObjectInputStream(client.getInputStream());
			while(!Thread.currentThread().isInterrupted()) {
			//	if(in.ready()) {
			String line = (String) in.readObject();
					//String line = in.readLine();
					System.out.println("[CLIENT WROTE] : " + line);
					if(line.equals(Protocol.connectionRequest)) {
						writeMessage(Protocol.connectionAccepted);
					}
						else if(line.equals(Protocol.loginRequest)) {
						writeMessage(Protocol.loginRequestAccepted);
					}
					else if(line.equals(Protocol.loginData)) {
						LoginUser u = (LoginUser) in.readObject();
						try {
							if(DatabaseHandler.getInstance().checkLogin(u)) {
								writeMessage(Protocol.loginSuccess);
								if(DatabaseHandler.getInstance().existUser(u.getUsername())) {
									writeMessage(Protocol.customerDashboard);
									User user = (User) DatabaseHandler.getInstance().getUser(u.getUsername());
									writeMessage(user);
								}else if(DatabaseHandler.getInstance().existPlace(u.getUsername())) {
									writeMessage(Protocol.staffDashboard);
									Place place = (Place) DatabaseHandler.getInstance().getUser(u.getUsername());
									writeMessage(place);
								}
							}else {
								writeMessage(Protocol.loginError);
								System.out.println("ERRORE");
							}
						} catch (SQLException e) {
							writeMessage(Protocol.loginError);
							e.printStackTrace();
						}
					}
					else if(line.equals(Protocol.customerRegistrationRequest)) {
						writeMessage(Protocol.customerRegistrationRequestAccepted);
					}else if(line.equals(Protocol.customerRegistrationData)) {
						User u = (User) in.readObject();
						System.out.println("[CLIENT WROTE] Nome :" + u.getNome() + " Cognome: " + u.getCognome() +  " Password: "+ u.getPassword() + System.lineSeparator());
						try {
							if(DatabaseHandler.getInstance().insertUser(u)) {
							System.out.println("[SERVER] Utente aggiunto correttamente!");
							//writeMessage(Protocol.customerAddedToDatabase);
							writeMessage(Protocol.loginSuccess);
							}else {
								System.out.println("[SERVER] Utente già presente!");
								writeMessage(Protocol.userExistError);
							}
						}catch(SQLException e) {
							SceneHandler.getInstance().showError("Impossibile terminare la procedura di registrazione! Riprova più tardi.");
							writeMessage(Protocol.databaseRegistrationError);
							System.out.println("[SERVER] Impossibile terminare la procedura di registrazione! Riprova più tardi." + e.getMessage() + System.lineSeparator());
						}
					}
					else if(line.equals(Protocol.staffRegistrationRequest)) {
						writeMessage(Protocol.staffRegistrationRequestAccepted);
					}
					else if(line.equals(Protocol.staffRegistrationData)) {
						Place p = (Place) in.readObject();
						System.out.println("[CLIENT WROTE] Nome :" + p.getNomeNegozio() + " Città: " + p.getCitta() +  " Password: "+ p.getPassword() + System.lineSeparator());
						try {
							if(DatabaseHandler.getInstance().insertPlace(p)) {
								System.out.println("[SERVER] Shop aggiunto correttamente!");
								
								writeMessage(Protocol.loginSuccess);
								
							}else {
								SceneHandler.getInstance().showError("Shop già presente!");
								System.out.println("[SERVER] Shop già presente!");
								writeMessage(Protocol.userExistError);
							}
						}catch(SQLException e) {
							SceneHandler.getInstance().showError("Impossibile terminare la procedura di registrazione! Riprova più tardi.");
							writeMessage(Protocol.databaseRegistrationError);
							System.out.println("[SERVER] Impossibile terminare la procedura di registrazione! Riprova più tardi." + e.getMessage() + System.lineSeparator());
							
						}
					}
					else if(line.equals(Protocol.fetchPassword)){
						String mail = (String) in.readObject();
						this.mail = mail;
						EmailSender sender = new EmailSender(mail);
						fetchPasswordCode = sender.generateCode();
						sender.sendMessage(mail, fetchPasswordCode);
					}
					else if(line.equals(Protocol.checkCode)) {
						String code = (String) in.readObject();
						if(code.equals(fetchPasswordCode)) {
							writeMessage(Protocol.changePassword);
						}else
							writeMessage(Protocol.changePasswordError);
					}
					else if(line.equals(Protocol.resetPassword)) {
						String newPassword = (String) in.readObject();
						try {
							if(DatabaseHandler.getInstance().updatePassword(newPassword, mail)) {
								writeMessage(Protocol.changePasswordSuccess);
							}
							else 
								writeMessage(Protocol.changePasswordError1);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					else if(line.equals(Protocol.getPlaceRequest)) {
						String city = (String) in.readObject();
						System.out.println(city);
						Places p = null;
						try {
							p = DatabaseHandler.getInstance().getPlaces(city);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						out.writeObject(p);
						out.flush();
					}
					else if(line.equals(Protocol.getJobsRequest)) {
						String shopName = (String) in.readObject();
						System.out.println(shopName);
						Jobs j = null;
						try {
							j = DatabaseHandler.getInstance().getJobs(shopName);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						out.writeObject(j);
						out.flush();
					}
					else if(line.equals(Protocol.addReservationRequest)) {
					    Reservation reservation = (Reservation) in.readObject();
						try {
							if(DatabaseHandler.getInstance().getAvailability(reservation)) {
								DatabaseHandler.getInstance().addReservation(reservation);
								writeMessage(Protocol.addReservationRequestAccepted);
							}else
								writeMessage(Protocol.reservationNotAvailableError);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					else if(line.equals(Protocol.getReservations)) {
						String username = (String) in.readObject();
						try {
							Reservations res = DatabaseHandler.getInstance().getReservations(username);
							out.writeObject(Protocol.OK);
							out.writeObject(res);
						} catch (SQLException e) {
							out.writeObject(Protocol.reservationsError);
							e.printStackTrace();
						}
					}
					else if(line.equals(Protocol.getReservationsShop)) {
						String placeName = (String) in.readObject();
						try {
							Reservations res = DatabaseHandler.getInstance().getReservationsShop(placeName);
							out.writeObject(Protocol.OK);
							out.writeObject(res);
						}catch (SQLException e) {
							out.writeObject(Protocol.reservationsError);
							e.printStackTrace();
						}
					}
					else if(line.equals(Protocol.acceptReservation)) {
						Reservation r = (Reservation) in.readObject();
						try {
							if(DatabaseHandler.getInstance().acceptReservation(r)) {
								writeMessage(Protocol.OK);
							}else {
								writeMessage(Protocol.ERROR);
							}
						} catch (SQLException e) {
							writeMessage(Protocol.databaseError);
							e.printStackTrace();
						}
					}
					else if(line.equals(Protocol.removeReservation)) {
						Reservation r = (Reservation) in.readObject();
						try {
							if(DatabaseHandler.getInstance().deleteReservation(r)) {
								writeMessage(Protocol.OK);
							}else {
								writeMessage(Protocol.ERROR);
							}
						} catch (SQLException e) {
							writeMessage(Protocol.databaseError);
							e.printStackTrace();
						}
					}
					else if(line.equals(Protocol.getProfitti)) {
						String placeName = (String) in.readObject();
						try {
							Integer res = DatabaseHandler.getInstance().getProfitti(placeName);
							writeMessage(res.toString());
						} catch (SQLException e) {
							writeMessage(Protocol.ERROR);
							e.printStackTrace();
						}
					}
					else if(line.equals(Protocol.getCosti)) {
						String placeName = (String) in.readObject();
						try {
							Integer res = DatabaseHandler.getInstance().getCosti(placeName);
							writeMessage(res.toString());
						} catch (SQLException e) {
							writeMessage(Protocol.ERROR);
							e.printStackTrace();
						}
					}
					else if(line.equals(Protocol.addCost)) {
						Cost c = (Cost) in.readObject();
						try {
							DatabaseHandler.getInstance().addCost(c);
							writeMessage(Protocol.OK);
						} catch (SQLException e) {
							writeMessage(Protocol.ERROR);
							e.printStackTrace();
						}
					}
					else if(line.equals(Protocol.deleteJob)) {
						Job j = (Job) in.readObject();
						try {
							DatabaseHandler.getInstance().deleteJob(j.getNomePrestazione(), j.getPlaceName());
							writeMessage(Protocol.OK);
						} catch (SQLException e) {
							writeMessage(Protocol.ERROR);
							e.printStackTrace();
						}
					}
					else if(line.equals(Protocol.addJob)) {
						Job j = (Job) in.readObject();
						try {
							DatabaseHandler.getInstance().addJob(j);
							writeMessage(Protocol.OK);
						} catch (SQLException e) {
							writeMessage(Protocol.ERROR);
							e.printStackTrace();
						}
					}
					else if(line.equals(Protocol.updateJob)) {
						Job j = (Job) in.readObject();
						String newPrice = (String) in.readObject();
						String newName = (String) in.readObject();
						String newDuration = (String) in.readObject();
						try {
							DatabaseHandler.getInstance().updateJob(j, newPrice, newName, newDuration);
							writeMessage(Protocol.OK);
						} catch (SQLException e) {
							writeMessage(Protocol.ERROR);
							e.printStackTrace();
						}
					}

			}
			
		}catch(IOException e) {
			try {
				closeStreams();
			} catch (IOException e1) {
				System.out.println("ERRORE");
				e1.printStackTrace();
			}
			System.out.println("[SERVER] : Impossibile stabilire una connessione ..." + System.lineSeparator());
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} 
	}

}
