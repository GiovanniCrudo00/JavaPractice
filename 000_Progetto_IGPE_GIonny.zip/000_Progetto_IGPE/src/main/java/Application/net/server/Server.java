package Application.net.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server implements Runnable{
	private ServerSocket server;
	private ExecutorService executor;
	
	public Server() {
		executor = Executors.newCachedThreadPool();
	}
	
	
	public void start() {
		try {
			server = new ServerSocket(8000);
			Thread t = new Thread(this);
			t.start();
		}catch (IOException e) {
			System.out.println("[SERVER] Errore durante l'avvio del server");
		}
	}
	
	public void run() {
		while(!Thread.currentThread().isInterrupted()) {
			try {
				System.out.println("[SERVER] Aspettando nuove connessioni ..." + System.lineSeparator());
				Socket client = server.accept();
				System.out.println("[SERVER] Client connesso " + System.lineSeparator());
				MessagesHandler handler = new MessagesHandler(client);
				executor.submit(handler);
			}catch(IOException e) {
				System.out.println("[SERVER] Errore di connessione.");
				e.printStackTrace();
				return;
			}
		}
		
	}
}
