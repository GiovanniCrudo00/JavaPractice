package Application.net.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.security.crypto.bcrypt.BCrypt;

import Application.logic.Cost;
import Application.logic.Job;
import Application.logic.Reservation;
import Application.logic.Reservations;
import Application.net.common.Jobs;
import Application.net.common.LoginUser;
import Application.net.common.Place;
import Application.net.common.Places;
import Application.net.common.User;

public class DatabaseHandler {
	
	private Connection conn = null;
	private static DatabaseHandler instance = null;
	
	private DatabaseHandler() {
		try {
			conn = DriverManager.getConnection("jdbc:sqlite:Database.db");
		} catch (SQLException e) {
			System.out.println("[DATABASE HANDLER] : Errore di connessione al database!" + e.getMessage() + System.lineSeparator());
		}
	}
	static public DatabaseHandler getInstance() {
		if(instance == null)
			instance = new DatabaseHandler();
		return instance;
	}
	
	public synchronized boolean insertUser(User u) throws SQLException{
		if(conn == null || conn.isClosed() || u == null) return false;
		if(existUser(u)) return false;
		
		String query = "INSERT INTO users VALUES(?,?,?,?,?,?,?,?,?)";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, u.getNome());
		p.setString(2, u.getCognome());
		p.setString(3, u.getDataDiNascita());
		p.setString(4, u.getIndirizzo());
		p.setString(5, u.getNumeroCivico());
		p.setString(6, u.getCitta());
		p.setString(7, u.getMail());
		p.setString(8, u.getUsername());
		p.setString(9, u.getPassword());
		try {
		p.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
		p.close();
		return true;	
	}
	
	public synchronized boolean insertPlace(Place p) throws SQLException{
		if(conn == null || conn.isClosed() || p == null) return false;
		if(existPlace(p)) return false;
		
		String query = "INSERT INTO places VALUES(?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(query);
		ps.setString(1,  p.getNomeNegozio());
		ps.setString(2,  "0.0");
		ps.setString(3,  p.getCitta());
		ps.setString(4,  p.getCap());
		ps.setString(5,  p.getOrarioInizio());
		ps.setString(6,  p.getOrarioFine());
		ps.setString(7,  p.getVia());
		ps.setString(8,  p.getNumeroCivico());
		ps.setString(9,  p.getPassword());
		ps.setString(10, p.getMail());
		try {
		ps.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
		ps.close();
		return true;	
	}
	
	public synchronized boolean existUser(User u) throws SQLException {
		if(conn == null || conn.isClosed() || u == null) return false;
		String query = "SELECT * FROM users WHERE username = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, u.getUsername());
		ResultSet set =  p.executeQuery();
		boolean result = set.next();
		p.close();
		return result;
	}
	public synchronized boolean existUser(String username) throws SQLException {
		if(conn == null || conn.isClosed() || username == null) return false;
		String query = "SELECT * FROM users WHERE username = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, username);
		ResultSet set =  p.executeQuery();
		boolean result = set.next();
		p.close();
		set.close();
		return result;
	}
	
	public synchronized boolean existPlace(Place p) throws SQLException {
		if(conn == null || conn.isClosed() || p == null) return false;
		String query = "SELECT * FROM places WHERE nomeNegozio = ?;";
		PreparedStatement ps = conn.prepareStatement(query);
		ps.setString(1, p.getNomeNegozio());
		ResultSet set =  ps.executeQuery();
		boolean result = set.next();
		ps.close();
		return result;
	}
	
	public synchronized boolean existPlace(String username) throws SQLException {
		if(conn == null || conn.isClosed() || username == null) return false;
		String query = "SELECT * FROM places WHERE NomeNegozio = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, username);
		ResultSet set =  p.executeQuery();
		boolean result = set.next();
		p.close();
		set.close();
		return result;
	}
	
	public synchronized Place getPlace(String username) throws SQLException {
		Place place = null;
		if(conn == null || conn.isClosed() || username == null) return place;
		String query = "SELECT * FROM places WHERE NomeNegozio = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, username);
		ResultSet set =  p.executeQuery();
		place = new Place(set.getString("NomeNegozio"), Float.parseFloat(set.getString("Valutazione")),
							set.getString("OrarioInizio"), set.getString("OrarioFine"),
							set.getString("Citta"), set.getString("CAP"), set.getString("Via"),
							set.getString("NumeroCivico"), set.getString("password"), set.getString("Mail"));
		p.close();
		set.close();
		return place;
	}
	
	public synchronized boolean updatePassword(String newPasswrod, String mail) throws SQLException {
		if(conn == null || conn.isClosed()) return false;
		String query = "UPDATE users SET Password = ? WHERE Mail = ?";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, newPasswrod);
		p.setString(2, mail);
		if(p.executeUpdate() == 0) {
			p.close();
			String query1 = "UPDATE places SET password = ? WHERE Mail = ?";
			PreparedStatement p1 = conn.prepareStatement(query1);
			p1.setString(1, newPasswrod);
			p1.setString(2, mail);
			if(p1.executeUpdate() == 0) {
				System.out.println("[DATABASE HANDLER] : l'utente non esiste");
				p1.close();
				return false;
			}
		}
		return true;
	}
	
	public synchronized Object getUser(String username) throws SQLException{
		if(conn == null || conn.isClosed() || username == null) return null;
		String query = "SELECT * FROM users WHERE username = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, username);
		ResultSet set = p.executeQuery();
		if(set.next()) return new User(set.getString("Nome"), set.getString("Cognome"),
									   set.getString("DataDiNascita"), set.getString("Indirizzo"),
									   set.getString("NumeroCivico"), set.getString("Citta"),
									   set.getString("Mail"), set.getString("Username"), set.getString("Password"));
		else {
			p.close();
			set.close();
			String query1 = "SELECT * FROM places WHERE NomeNegozio = ?;";
			PreparedStatement p1 = conn.prepareStatement(query1);
			p1.setString(1, username);
			ResultSet set1 = p1.executeQuery();
			if(set1.next()) return new Place(set1.getString("NomeNegozio"),Float.parseFloat(set1.getString("Valutazione")),
											 set1.getString("OrarioInizio"),set1.getString("OrarioFine"),
											 set1.getString("Citta"),set1.getString("CAP"),
											 set1.getString("Via"),set1.getString("NumeroCivico"),
											 set1.getString("password"),set1.getString("Mail"));
			p1.close();
			set1.close();
		}
		return null;
	}
	
	
	public synchronized boolean checkLogin(LoginUser u) throws SQLException {
		if(conn == null || conn.isClosed() || u == null) return false;
		String query = "SELECT Password FROM users WHERE username = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, u.getUsername());
		ResultSet set = p.executeQuery();
		if(set.next() && BCrypt.checkpw(u.getPassword(), (String) set.getString("Password")) ) {
			System.out.println("[DATABASE HANDLER] : <Customer> Le password corrispondono");
			return true;
		}else {
			String query1 = "SELECT Password FROM places WHERE NomeNegozio = ?;";
			p.close();
			set.close();
			PreparedStatement p1 = conn.prepareStatement(query1);
			p1.setString(1, u.getUsername());
			ResultSet set1 = p1.executeQuery();
			if(set1.next() && BCrypt.checkpw(u.getPassword(), (String) set1.getString("Password"))) {
				System.out.println("[DATABASE HANDLER] : <Place> Le password corrispondono");
				return true;
			} else {
				p1.close();
				set1.close();
				System.out.println("[DATABASE HANDLER] : Le password NON corrispondono");
				return false;
			}
		}
	}
	
	public synchronized Jobs getJobs(String placeName) throws SQLException {
		Jobs j = new Jobs();
		if(conn != null && !conn.isClosed() && placeName != null) {
			String query = "SELECT * FROM jobs WHERE PlaceName = ?;";
			PreparedStatement p = conn.prepareStatement(query);
			p.setString(1, placeName);
			ResultSet set = p.executeQuery();
			while(set.next()) {
				Job job = new Job(set.getString("JobName"), set.getString("Price"),set.getString("Duration") , set.getString("PlaceName"), set.getString("Eliminato"));
				j.jobs.add(job);
			}
		}
		return j;
	}
	
	public synchronized boolean addJob(Job j) throws SQLException{
		if(conn == null || conn.isClosed() || j == null) return false;
		String query = "INSERT INTO jobs VALUES(?,?,?,?,?,?);";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, null);
		p.setString(2, j.getPlaceName());
		p.setString(3, j.getCosto());
		p.setString(4, j.getTempoEsecuzione());
		p.setString(5, j.getNomePrestazione());
		p.setString(6, "0");
		p.executeUpdate();
		return true;
	}
	
	public synchronized Job updateJob(Job j, String newPrice, String newJobName, String newJobDuration) throws SQLException {
		if(conn == null || conn.isClosed()) return j;
		String query = "UPDATE jobs SET Price = ? ,JobName = ?, Duration = ? WHERE JobName = ? AND PlaceName = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		//IF String are null the content remain the same
		if(newPrice != null) {
			p.setString(1, newPrice);
			j.setCosto(newPrice);
		}
		else
			p.setString(1, j.getCosto());
		if(newJobName != null) {
		p.setString(2, newJobName);
		j.setNomePrestazione(newJobName);
		}
		else
			p.setString(2, j.getNomePrestazione());
		if(newJobDuration != null) {
		p.setString(3, newJobDuration);
		j.setCosto(newPrice);
		}
		else
			p.setString(3, j.getTempoEsecuzione());
		
		p.setString(4, j.getNomePrestazione());
		p.setString(5, j.getPlaceName());
		p.executeUpdate();
		return j;
	}
	
	
	public synchronized boolean deleteJob(String nomeJob, String jobPlace) throws SQLException{
		if(conn == null || conn.isClosed() || nomeJob == null || jobPlace == null) return false;
		String query = "UPDATE jobs SET Eliminato = ? WHERE JobName = ? AND PlaceName = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, "1");
		p.setString(2, nomeJob);
		p.setString(3, jobPlace);
		p.executeUpdate();
//		String query = "DELETE FROM jobs WHERE JobName = ? AND PlaceName = ?;";
//		PreparedStatement p = conn.prepareStatement(query);
//		p.setString(1, nomeJob);
//		p.setString(2, jobPlace);
//		p.executeUpdate();
		return true;
	}
	
	public synchronized Places getPlaces(String city) throws SQLException{
		if(conn == null || conn.isClosed() || city == null) return null;
		String query = "SELECT * FROM places WHERE Citta = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, city);
		ResultSet set = p.executeQuery();
		Places places = new Places();
		while(set.next()) {
			Place place = new Place(set.getString("NomeNegozio"),Float.parseFloat(set.getString("Valutazione")),
									set.getString("OrarioInizio"),set.getString("OrarioFine"),
									set.getString("Citta"),set.getString("CAP"),
									set.getString("Via"),set.getString("NumeroCivico"),
									set.getString("password"),set.getString("Mail"));
			places.places.add(place);
		}
		return places;
	}
	
	
	public synchronized boolean getAvailability(Reservation reservation) throws SQLException{
		if(conn == null || conn.isClosed()) return false;
		String query = "SELECT * FROM reservations WHERE PlaceName = ? AND Ora = ? AND Data = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, reservation.getNegozio());
		p.setString(2, reservation.getOra());
		p.setString(3, reservation.getData());
		ResultSet set = p.executeQuery();
		return !set.next();
	}
	
	
	public synchronized boolean addReservation(Reservation reservation) throws SQLException{
		if(conn == null || conn.isClosed()) return false;
		String query = "INSERT INTO reservations VALUES(?,?,?,?,?,?);";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, null);
		p.setString(2, reservation.getCliente());
		p.setString(3, reservation.getNegozio());
		p.setString(4, reservation.getOra());
		p.setBoolean(5, false);
		p.setString(6, reservation.getData());
		p.executeUpdate();
		
		
		String query1 = "SELECT ID FROM reservations WHERE CustomerUsername = ? AND PlaceName = ? AND Ora = ? AND Data = ?;";
		PreparedStatement p1 = conn.prepareStatement(query1);
		p1.setString(1, reservation.getCliente());
		p1.setString(2, reservation.getNegozio());
		p1.setString(3, reservation.getOra());
		p1.setString(4, reservation.getData());
		
		ResultSet set = p1.executeQuery();
		if(set.next()) {
			for(int i = 0; i < reservation.getJobs().jobs.size(); ++i) {
				String query2 = "INSERT INTO reservationJobs VALUES(?,?);";
				PreparedStatement p2 = conn.prepareStatement(query2);
				p2.setString(1, set.getString("ID"));
				String query3 = "SELECT ID FROM jobs WHERE PlaceName = ? AND JobName = ?;";
				PreparedStatement p3 = conn.prepareStatement(query3);
				p3.setString(1, reservation.getNegozio());
				p3.setString(2, reservation.getJobs().jobs.get(i).getNomePrestazione());
				ResultSet set3 = p3.executeQuery();
				if(set3.next()) {
				p2.setString(2, set3.getString("ID"));
				p2.executeUpdate();
				} else
					return false;
			}
		}else return false;
		return true;
	}
	
	public synchronized ResultSet getReservations(String placeName , String data) throws SQLException{
		ResultSet set = null;
		if(conn != null && !conn.isClosed() && placeName != null && data != null) {
			String query = "SELECT * FROM reservations WHERE placeName = ? AND data = ?;";
			PreparedStatement p = conn.prepareStatement(query);
			p.setString(1, placeName);
			p.setString(2, data);
			set = p.executeQuery();
		}
		return set;
	}
	
	public synchronized Reservations getReservations(String username) throws SQLException{
		if(conn == null || conn.isClosed() || username == null) {
			System.out.println("ERRORE " + username);
			return null;
		}
		String query = "SELECT * FROM reservations WHERE CustomerUsername = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, username);
		ResultSet set = p.executeQuery();
		Reservations res = new Reservations();
		while(set.next()) {
			String idReservation = set.getString("ID");
			String query1 = "SELECT * FROM reservationJobs WHERE IDReservation = ?;";
			PreparedStatement p1 = conn.prepareStatement(query1);
			p1.setString(1, idReservation);
			ResultSet set1 = p1.executeQuery();
			set1.next();
			Jobs j = new Jobs();
			do{
					String query2 = "SELECT * FROM jobs WHERE ID = ?;";
					PreparedStatement p2 = conn.prepareStatement(query2);
					p2.setString(1, set1.getString("IDJob"));
					ResultSet set2 = p2.executeQuery();
					set2.next();
					Job job = new Job(set2.getString("JobName"), set2.getString("Price"),
									  set2.getString("Duration") ,set2.getString("PlaceName"), set2.getString("Eliminato"));
					j.jobs.add(job);
				
			}while(set1.next());
			Reservation reservation = new Reservation(username, set.getString("PlaceName"),j, set.getString("Ora"), set.getString("Data"), set.getString("Accettato"));
			res.reservations.add(reservation);
		}
		
		for(int i = 0; i < res.reservations.size(); ++i)
			System.out.println(res.reservations.get(i).toString());
		return res;
	}
	
	public synchronized Reservations getReservationsShop(String placeName) throws SQLException{
		if(conn == null || conn.isClosed() || placeName == null) {
			System.out.println("ERRORE " + placeName);
			return null;
		}
		String query = "SELECT * FROM reservations WHERE PlaceName = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, placeName);
		ResultSet set = p.executeQuery();
		Reservations res = new Reservations();
		while(set.next()) {
			String idReservation = set.getString("ID");
			String query1 = "SELECT * FROM reservationJobs WHERE IDReservation = ?;";
			PreparedStatement p1 = conn.prepareStatement(query1);
			p1.setString(1, idReservation);
			ResultSet set1 = p1.executeQuery();
			set1.next();
			Jobs j = new Jobs();
			do{
				String query2 = "SELECT * FROM jobs WHERE ID = ?;";
				PreparedStatement p2 = conn.prepareStatement(query2);
				p2.setString(1, set1.getString("IDJob"));
				ResultSet set2 = p2.executeQuery();
				set2.next();
				Job job = new Job(set2.getString("JobName"), set2.getString("Price"),
								  set2.getString("Duration") ,set2.getString("PlaceName"), set2.getString("Eliminato"));
				j.jobs.add(job);
				
			}while(set1.next());
			Reservation reservation = new Reservation(placeName, set.getString("PlaceName"),j, set.getString("Ora"), set.getString("Data"), set.getString("Accettato"));
			System.out.println(reservation.toString());
			res.reservations.add(reservation);
		}
		System.out.println("ACTION");
		for(int i = 0; i < res.reservations.size(); ++i)
			System.out.println(res.reservations.get(i).toString());
		return res;
	}
	
	public boolean acceptReservation(Reservation r) throws SQLException{
		if(conn == null || conn.isClosed() || r == null) return false;
		String query = "SELECT ID FROM reservations WHERE PlaceName = ? AND Ora = ? AND Data = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, r.getNegozio());
		p.setString(2, r.getOra());
		p.setString(3, r.getData());
		ResultSet set = p.executeQuery();
		String id = set.getString("ID");
		String query1 = "UPDATE reservations SET Accettato = 1 WHERE ID = ?;";
		PreparedStatement p1 = conn.prepareStatement(query1);
		p1.setString(1, id);
		p1.executeUpdate();
		return true;
	}
	
	public boolean deleteReservation(Reservation r) throws SQLException{
		if(conn == null || conn.isClosed() || r == null) return false;
		String query = "SELECT ID FROM reservations WHERE PlaceName = ? AND Ora = ? AND Data = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, r.getNegozio());
		p.setString(2, r.getOra());
		p.setString(3, r.getData());
		ResultSet set = p.executeQuery();
		String id = set.getString("ID");
		String query1 = "DELETE FROM reservationJobs WHERE IDReservation = ?;";
		PreparedStatement p1 = conn.prepareStatement(query1);
		p1.setString(1, id);
		p1.executeUpdate();
		String query2 = "DELETE FROM reservations WHERE ID = ?;";
		PreparedStatement p2 = conn.prepareStatement(query2);
		p2.setString(1, id);
		p2.executeUpdate();
		return true;
	}
	
	public int getProfitti(String placeName) throws SQLException {
		if(conn == null || conn.isClosed() || placeName == null) return 0;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		Reservations res = getReservationsShop(placeName);
		int tot = 0;
		for(int i = 0; i < res.reservations.size(); ++i) {
			Reservation r = res.reservations.get(i);
			String data = r.getData();
			String[] datas = data.split("-");
			int subtot = 0;
			if(now.getMonthValue() == Integer.parseInt(datas[1]) && res.reservations.get(i).getAccettato().equals("1")){
				for(int j = 0; j < r.getJobs().jobs.size(); ++j) {
					subtot += Integer.parseInt(r.getJobs().jobs.get(j).getCosto());
				}
			}
			tot += subtot;
		}
		return tot;
	}
	
	public int getCosti(String placeName) throws SQLException{
		if(conn == null || conn.isClosed() || placeName == null) return 0;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		String query = "SELECT * FROM costs WHERE NomeNegozio = ?;";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, placeName);
		ResultSet set = p.executeQuery();
		int tot = 0;
		while(set.next()) {
			String data = set.getString("Data");
			String[] datas = data.split("-");
			if(now.getMonthValue() == Integer.parseInt(datas[1]))
				tot += Integer.parseInt(set.getString("Importo"));
		}
		return tot;
	}
	
	public boolean addCost(Cost c) throws SQLException{
		if(conn == null || conn.isClosed() || c == null) return false;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		String query = "INSERT INTO costs VALUES(?,?,?,?);";
		PreparedStatement p = conn.prepareStatement(query);
		p.setString(1, c.getShopName());
		p.setString(2, c.getMotivo());
		p.setString(3, c.getImporto());
		Integer mese = now.getMonthValue();
		String month;
		if(mese < 10) month = "0" + mese.toString();
		else month = mese.toString();
		String data = now.getYear() + "-" + month + "-" + now.getDayOfMonth();
		p.setString(4, data);
		p.executeUpdate();
		return true;
	}
	
}
