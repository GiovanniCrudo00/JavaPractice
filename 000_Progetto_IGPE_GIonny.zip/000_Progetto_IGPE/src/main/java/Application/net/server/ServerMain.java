package Application.net.server;

public class ServerMain {
	public static void main(String[] args) {
		Server s = new Server();
		s.start();
	}
	
}
