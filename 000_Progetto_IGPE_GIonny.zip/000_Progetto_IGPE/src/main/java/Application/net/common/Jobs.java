package Application.net.common;

import java.io.Serializable;
import java.util.Vector;

import Application.logic.Job;

public class Jobs implements Serializable{
	private static final long serialVersionUID = -1921428209337108310L;
	
	public Vector<Job> jobs;
	public Jobs() {
		jobs = new Vector<Job>();
	}

}
