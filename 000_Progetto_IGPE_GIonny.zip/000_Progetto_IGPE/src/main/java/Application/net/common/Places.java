package Application.net.common;

import java.io.Serializable;
import java.util.Vector;

public class Places implements Serializable{
	private static final long serialVersionUID = -4168004161199172463L;
	public Vector<Place> places;
	public Places() {
		places = new Vector<Place>();
	}
	
	
}
