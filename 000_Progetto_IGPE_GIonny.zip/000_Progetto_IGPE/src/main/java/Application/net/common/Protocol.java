package Application.net.common;

public class Protocol {
	//CONNECTION
	public final static String connectionRequest = "connection request";
	public final static String connectionAccepted = "connection accepted";
	
	//FORGOTTEN PASSWORD
	public final static String forgottenPassword = "forgotten password";
	public final static String fetchPassword = "fetch password";
	public final static String changePassword = "change password";
	public final static String changePasswordError = "The codes doesn't match";
	public final static String changePasswordError1 = "Error during reset the password";
	public final static String checkCode = "check code";
	public final static String resetPassword = "reset password";
	public final static String changePasswordSuccess = "fetch password success";
	
	//REGISTRATION
	public final static String customerRegistrationRequest = "customer registration request";
	public final static String staffRegistrationRequest = "staff registration request";
	public final static String customerRegistrationRequestAccepted = "customer registration request accepted";
	public final static String staffRegistrationRequestAccepted = "staff registration request accepted";
	public final static String customerRegistrationData = "customer registration data";
	public final static String staffRegistrationData = "staff registration data";
	public final static int STAFF_TYPE = 0;
	public final static int CUSTOMER_TYPE = 1;
	public final static String customerAddedToDatabase = "customer correctly added to database";
	public final static String staffAddedToDatabase = "staff correctly added to database";
	public final static String databaseRegistrationError = "error while saving the customer";
	
	//DATABASE
	public final static String userExistError = "user already exists";
	public final static String userDontExistError = "user dont exists";
	public final static String jobAdded = "job correctly added";
	public final static String getPlaceRequest = "get Places request";
	public final static String getJobsRequest = "get Jobs request";
	public final static String addReservationRequest = "add reservation request";
	public final static String addReservationRequestAccepted = "add reservation request accepted";
	public final static String reservationNotAvailableError = "already exists a reservation for that hour";
	public final static String getReservations = "get all reservations";
	public final static String databaseError = "database error";
	
	//LOGIN
	public final static String loginRequest = "login request";
	public final static String loginRequestAccepted = "login request accepted";
	public final static String loginData = "login data";
	public final static String loginSuccess = "login success";
	public final static String loginError = "login error";
	public final static String loginCredentialError = "wrong password or username";
	
	//DASHBOARD CUSTOMER
	public final static String customerDashboard = "customer";
	public final static String staffDashboard = "staff";
	public final static String reservationsError = "reservation Error";
	public final static String OK = "ok";
	public final static String ERROR = "error";
	
	//DASHBOARD SHOP
	public final static String getReservationsShop = "get reservations shop";
	public final static String acceptReservation = "accept reservation";
	public final static String removeReservation = "remove reservation";
	public final static String getProfitti = "get profits";
	public final static String getCosti = "get costs";
	public final static String addCost = "add cost";
	public final static String deleteJob = "delete job";
	public final static String addJob = "add job";
	public final static String updateJob = "update job";
	
}
