package Application.net.common;

import java.io.Serializable;
import java.util.Vector;
import Application.logic.Job;

public class Place implements Serializable{
	private static final long serialVersionUID = -548277883117852011L;
	
	String nomeNegozio;
	Float valutazione; // scala 1 - 5
	String orarioInizio;
	String orarioFine;
	String citta;
	String cap;
	String via;
	String numeroCivico;
	String password;
	String mail;
	
	
	Vector<Job> prestazioni;
	
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	//Vector<Image> galleriaFoto;
	public Place(String nomeNegozio, Float valutazione, String orarioInizio, String orarioFine, String citta,
			String cap, String via, String numeroCivico, String password, String mail) {
		super();
		this.nomeNegozio = nomeNegozio;
		this.valutazione = valutazione;
		this.orarioInizio = orarioInizio;
		this.orarioFine = orarioFine;
		this.citta = citta;
		this.cap = cap;
		this.via = via;
		this.numeroCivico = numeroCivico;
		this.password = password;
		this.mail = mail;
		
	}
	
	public Place() {}

	public String getNomeNegozio() {
		return nomeNegozio;
	}

	public void setNomeNegozio(String nomeNegozio) {
		this.nomeNegozio = nomeNegozio;
	}

	public Float getValutazione() {
		return valutazione;
	}

	public void setValutazione(Float valutazione) {
		this.valutazione = valutazione;
	}

	public String getOrarioInizio() {
		return orarioInizio;
	}

	public void setOrarioInizio(String orarioInizio) {
		this.orarioInizio = orarioInizio;
	}

	public String getOrarioFine() {
		return orarioFine;
	}

	public void setOrarioFine(String orarioFine) {
		this.orarioFine = orarioFine;
	}

	public String getCitta() {
		return citta;
	}

	public void setCitta(String citta) {
		this.citta = citta;
	}

	public String getCap() {
		return cap;
	}

	public void setCap(String cap) {
		this.cap = cap;
	}

	public String getVia() {
		return via;
	}

	public void setVia(String via) {
		this.via = via;
	}

	public String getNumeroCivico() {
		return numeroCivico;
	}

	public void setNumeroCivico(String numeroCivico) {
		this.numeroCivico = numeroCivico;
	}
	
	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}
	
	public void updateJob(int i , Job j) {
		prestazioni.set(i, j);
	}
	
	public boolean removeJob(Job j) {
		return prestazioni.remove(j);
	}
	
	
	public boolean addJob(Job j) {
		return prestazioni.add(j);
	}
	
	


}
