package Application.net.common;

import java.util.Properties;
import java.util.Random;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

public class EmailSender {
	private String mailFrom = "marasco.gionnyx@gmail.com";
	private String pwd = "cb00440a3da934";
	private String name = "57b837fe413ea0";
	private String host = "smtp.mailtrap.io";
	private String port = "2525";
	private Session session;
	private String mailTo;
	
	public EmailSender(String mailTo) {
		this.mailTo = mailTo;
		 Properties props = new Properties();
	     props.put("mail.smtp.auth", "true");
	     props.put("mail.smtp.starttls.enable", "true");
	     props.put("mail.smtp.host", host);
	     props.put("mail.smtp.port", port);
	     session = Session.getInstance(props,
	             new Authenticator() {
	                protected PasswordAuthentication getPasswordAuthentication() {
	                   return new PasswordAuthentication(name, pwd);
	        }
	       });
	     
	}
	
	public boolean sendMessage(String subject, String text) {
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(mailFrom));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mailTo));
			message.setSubject(subject);
			message.setText("Il tuo codice di verifica è : " + text);
			Transport.send(message);
			System.out.println("[EMAIL SENDER] : mail inviata correttamente!" + System.lineSeparator());
			return true;
		}catch(MessagingException e) {
			e.printStackTrace();
			return false;
		}
	}
	public boolean sendMessage(String subject, String text, boolean t) {
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(mailFrom));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mailTo));
			message.setSubject(subject);
			message.setText(text);
			Transport.send(message);
			System.out.println("[EMAIL SENDER] : mail inviata correttamente!" + System.lineSeparator());
			return true;
		}catch(MessagingException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	public String generateCode() {
		StringBuffer code = new StringBuffer();
		Random r = new Random();
		for(int i = 0; i < 6; ++i) {
			code.append(r.nextInt(10));
		}
		return code.toString();
	}
	
	
	
	
}
