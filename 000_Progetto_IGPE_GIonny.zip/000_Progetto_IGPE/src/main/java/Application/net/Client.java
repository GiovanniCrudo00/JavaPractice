package Application.net;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import Application.app.SceneHandler;
import Application.logic.Cost;
import Application.logic.Job;
import Application.logic.Reservation;
import Application.logic.Reservations;
import Application.net.common.Jobs;
import Application.net.common.LoginUser;
import Application.net.common.Place;
import Application.net.common.Places;
import Application.net.common.Protocol;
import Application.net.common.User;

public class Client implements Runnable{
	
	private static Client instance = null;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	private Socket socket = null;
	private User user = null;
	private Place place = null;
	
	public void closeConnections() throws IOException {
		instance = null;
		in.close();
		in = null;
		out.close(); 
		out = null;
		socket.close();
		socket = null;
		user = null;
		place = null;
	}
	
	
	
//	private PrintWriter out;
//	private BufferedReader in;
//	private Scanner scanner;
	
	
	private Client() {
		try {
			socket = new Socket("localhost", 8000);
			out = new ObjectOutputStream(socket.getOutputStream());
		}catch(IOException e) {
			out = null;
			in = null;
			SceneHandler.getInstance().showError("Cannot connect to the server");
			e.printStackTrace();
		}
	}
	
	public static Client getInstance() {
		if(instance == null)
			instance = new Client();
		return instance;
	}
	
	private boolean sendMessage(Object message) {
		if(out == null)
			return false;
		try {
			out.writeObject(message);
			out.flush();
		} catch (IOException e) {
			out = null;
			return false;
		}
		return true;
	}
	
	public boolean sendMessage(String message) {
		return sendMessage((Object) message);
	}
	
	
	public String getCity() {
		if(place == null) {
			return user.getCitta();
		}else
			return place.getCitta();
	}
	
	public Places getAllShops(String city) {
		sendMessage(Protocol.getPlaceRequest);
		sendMessage(city);
		Places p = null;
		try {
			p = (Places) in.readObject();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return p;
	}
	
	
	public String loginAuthentication(String username, String password) throws IOException {
		sendMessage(Protocol.loginRequest);
		try {
			if(rcvMessage().equals(Protocol.loginRequestAccepted)) {
				sendMessage(Protocol.loginData);
				sendMessage(new LoginUser(username, password));
				if(rcvMessage().equals(Protocol.loginSuccess)) {
					System.out.println("[SERVER WROTE] : " + Protocol.loginSuccess);
					System.out.println("[CLIENT] login effettuato con SUCCESSO! " + System.lineSeparator());
					String responce = (String) rcvMessage();
					System.out.println(responce);
					if(responce.equals(Protocol.customerDashboard)) {
						System.out.println("CUSTOMER DASHBOARD");
						this.user = (User) in.readObject();
						System.out.println(user.getNome() + " " + user.getCognome());
						SceneHandler.getInstance().setCustomerDashboard();
					}else if(responce.equals(Protocol.staffDashboard)){
						System.out.println("STAFF DASHBOARD");
						this.place = (Place) in.readObject();
						System.out.println(place.getNomeNegozio() + " " + place.getCitta());
						SceneHandler.getInstance().setShopDashboard();
					}
				}else {
					SceneHandler.getInstance().showError("WRONG USERNAME OR PASSWORD");
				}
					
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
	public void customerRegistrationProcedure(User u) throws IOException{
		sendMessage(Protocol.connectionRequest);
		try {
			if(rcvMessage().equals(Protocol.connectionAccepted)) {
				sendMessage(Protocol.customerRegistrationRequest);
				try {
					if(rcvMessage().equals(Protocol.customerRegistrationRequestAccepted)) {
						sendMessage(Protocol.customerRegistrationData);
						sendMessage(u);
						if(rcvMessage().equals(Protocol.loginSuccess)) {
							this.user = u;
							SceneHandler.getInstance().setCustomerDashboard();
						}else
							SceneHandler.getInstance().showError("L'username che stai cercando di inserire è già stato preso da qualcun altro!");
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void ShopRegistrationProcedure(Place p) throws IOException{
		sendMessage(Protocol.connectionRequest);
		try {
			if(rcvMessage().equals(Protocol.connectionAccepted)) {
				sendMessage(Protocol.staffRegistrationRequest);
				try {
					if(rcvMessage().equals(Protocol.staffRegistrationRequestAccepted)) {
						sendMessage(Protocol.staffRegistrationData);
						sendMessage(p);
						String message = (String) rcvMessage();
						if(message.equals(Protocol.loginSuccess)) {
							this.place = p;
							SceneHandler.getInstance().setShopDashboard();
						}
						else if(message.equals(Protocol.userExistError))
							SceneHandler.getInstance().showError("L'username che stai cercando di inserire è già stato preso da qualche altro utente :C !");
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
   public void fetchPassword(String mail) throws IOException {
		sendMessage(Protocol.fetchPassword);
		sendMessage(mail);
		try {
			SceneHandler.getInstance().setFetchPasswordCodeScene();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void checkCode(String code) throws IOException{
		sendMessage(Protocol.checkCode);
		sendMessage(code);
		try {
			String responce = (String) rcvMessage();
			if(responce.equals(Protocol.changePassword))
				SceneHandler.getInstance().setResetPasswordScene();
			else {
				SceneHandler.getInstance().showError(Protocol.changePasswordError);
				return;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void resetPassword(String newPassword ) throws IOException{
		String hashedPassword = newPassword;
		sendMessage(Protocol.resetPassword);
		sendMessage(hashedPassword);
		String responce;
		try {
			responce = (String) rcvMessage();
			if(responce.equals(Protocol.changePasswordSuccess)) {
				SceneHandler.getInstance().setLoginScene();
			}else {
				SceneHandler.getInstance().showError(responce);
				SceneHandler.getInstance().setLoginScene();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	public Jobs getJobs(String shopName) {
		sendMessage(Protocol.getJobsRequest);
		sendMessage(shopName);
		Jobs j = null;
		try {
			j = (Jobs) in.readObject();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return j;
	}
	
	public void addJob(Job j) {
		sendMessage(Protocol.addJob);
		sendMessage(j);
		String responce;
		try {
			responce = (String) rcvMessage();
			if(responce.equals(Protocol.OK)) {
				SceneHandler.getInstance().showDialog("Job aggiunto correttamente");
			}else {
				SceneHandler.getInstance().showError("Ci sono stati problemi durante l'aggiunta del job");
				return;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void updateJob(Job j, String newName, String newDuration, String newPrice) {
		sendMessage(Protocol.updateJob);
		sendMessage(j);
		sendMessage(newPrice);
		sendMessage(newName);
		sendMessage(newDuration);
		String responce;
		try {
			responce = (String) rcvMessage();
			if(responce.equals(Protocol.OK)) {
				SceneHandler.getInstance().showDialog("Job modificato correttamente");
			}else {
				SceneHandler.getInstance().showError("Ci sono stati problemi durante la modifica del job");
				return;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void deleteJob(Job j) {
		sendMessage(Protocol.deleteJob);
		sendMessage(j);
		String responce;
		try {
			responce = (String) rcvMessage();
			if(responce.equals(Protocol.OK)) {
				SceneHandler.getInstance().showDialog("Job eliminato correttamente");
			}else {
				SceneHandler.getInstance().showError("Ci sono stati problemi durante l'eliminazione del job");
				return;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Reservations getReservations(String username) throws IOException{
		sendMessage(Protocol.getReservations);
		sendMessage(username);
		try {
			String responce = (String) rcvMessage();
			if(responce.equals(Protocol.OK)) {
			Reservations res = (Reservations) rcvMessage();
			return res;
			}
			return null;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public Reservations getReservations(String shopName, boolean x) throws IOException{
		sendMessage(Protocol.getReservationsShop);
		sendMessage(place.getNomeNegozio());
		try {
			String responce = (String) rcvMessage();
			if(responce.equals(Protocol.OK)) {
			Reservations res = (Reservations) rcvMessage();
			return res;
			}else {
				System.out.println(responce);
			return null;
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("ERRORE");
		return null;
	}
	
	
	public boolean addReservation(Reservation reservation) throws IOException {
		sendMessage(Protocol.addReservationRequest);
		sendMessage(reservation);
		try {
			if(rcvMessage().equals(Protocol.reservationNotAvailableError)) {
				SceneHandler.getInstance().showError(Protocol.reservationNotAvailableError);
				return false;
			}else
				return true;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	
	public boolean acceptReservation(Reservation r) {
		sendMessage(Protocol.acceptReservation);
		sendMessage(r);
		try {
			String message = (String) rcvMessage();
			if(message.equals(Protocol.OK)) {
				SceneHandler.getInstance().showDialog("La prenotazione è stata accettata correttamente!");
				return true;
			}
			else if(message.equals(Protocol.ERROR)) {
				SceneHandler.getInstance().showError("La prenotazione NON è stata accettata");
				return false;
			}
			else {
				SceneHandler.getInstance().showError(Protocol.databaseError);
				return false;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean removeReservation(Reservation r) throws IOException{
		sendMessage(Protocol.removeReservation);
		sendMessage(r);
		try {
			String message = (String) rcvMessage();
			if(message.equals(Protocol.OK)) {
				SceneHandler.getInstance().showDialog("La prenotazione è stata correttamente rifiutata!");
				return true;
			}
			else if(message.equals(Protocol.ERROR)) {
				SceneHandler.getInstance().showError("La prenotazione NON è stata rifiutata");
				return false;
			}
			else {
				SceneHandler.getInstance().showError(Protocol.databaseError);
				return false;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public Integer getProfitti(String placeName) {
		sendMessage(Protocol.getProfitti);
		sendMessage(placeName);
		try {
			return Integer.parseInt((String)rcvMessage());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	
	public Integer getCosti(String placeName) {
		sendMessage(Protocol.getCosti);
		sendMessage(placeName);
		try {
			String message = (String) rcvMessage();
			if(message.equals(Protocol.ERROR))
				return 0;
			return Integer.parseInt(message);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return 0;
	}
	
	public boolean addCosto(Cost c) {
		sendMessage(Protocol.addCost);
		sendMessage(c);
		try {
			String message = (String) in.readObject();
			if(message.equals(Protocol.OK))
				SceneHandler.getInstance().showDialog("Costo correttamente aggiunto!");
			else
				SceneHandler.getInstance().showError("Il costo inserito NON è stato aggiunto correttamente!");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return true;
	}
	
	public void run() {
		if(in == null)
			return;
		
		while(out != null) {
			System.out.println("[test]");
			String message;
			try {
				message = (String) in.readObject();
				if(message.equals(Protocol.connectionAccepted)) {
					System.out.println("[CLIENT] : connessione accettata");
				}
				System.out.println(message);
			} catch (IOException e) {
				out = null;
				SceneHandler.getInstance().showError("Lost connection...");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	public void reset() {
		instance = null;
		out = null;
		in = null;
		socket = null;
	}

	public Object rcvMessage() throws IOException, ClassNotFoundException {
		if(in == null)
			in = new ObjectInputStream(socket.getInputStream());
		return (Object) in.readObject();
	}
	
	public User getUser() {
		return this.user;
	}
	
	public Place getPlace() {
		return this.place;
	}
	
	
	

//	public void run() {
//		if(socket == null) return;
//		String message;
//		while(!Thread.currentThread().isInterrupted()) {
//			try {
//					message = in.readLine();
//					if(message == null) {
//						System.out.println("[CLIENT] : Connessione persa!" + System.lineSeparator());
//						return;
//					}
//					else if(message.equals(Protocol.connectionAccepted)) {
//						System.out.println("[SERVER WROTE] : " + message + System.lineSeparator());
//						scanner = new Scanner(System.in);
//						String choose = scanner.nextLine();
//						if(choose.equals(Protocol.customerRegistrationRequest)) {
//							
//							//Se vuoi registrati come cliente
//							System.out.println("[CLIENT] : hai scelto di registrarti");
//							sendMessage(Protocol.customerRegistrationRequest);
//							
//						}else if(choose.equals(Protocol.staffRegistrationRequest)) {
//							
//							//Se vuoi registrarti come personale
//							System.out.println("[CLIENT] : hai scelto di registrarti");
//							sendMessage(Protocol.staffRegistrationRequest);
//							
//						}else if(choose.equals(Protocol.loginRequest)) {
//							
//							//Se vuoi fare la login
//							System.out.println("[CLIENT] : hai scelto di fare la login");
//							sendMessage(Protocol.loginRequest);
//						}
//						else if(choose.equals(Protocol.forgottenPassword)) {
//							System.out.println("[CLIENT] : recupero password");
//							sendMessage(Protocol.fetchPassword);
//							System.out.println("[CLIENT] : Inserisci la tua mail");
//							String mail = scanner.next();
//							sendMessage(mail);
//							System.out.println("[CLIENT] : Inserisci il codice di verifica che è stato inviato alla tua mail");
//							String userCode = scanner.next();
//							sendMessage(userCode);
//						}
//						
//						
//					}else if(message.equals(Protocol.changePassword)) {
//						System.out.println("[CLIENT] : Inserisci una nuova password");
//						String newPassword = scanner.next();
//						String hashedPassword = BCrypt.hashpw(newPassword, BCrypt.gensalt(12));
//						sendMessage(hashedPassword);
//						String responce = in.readLine();
//						System.out.println("[SERVER WROTE] : " + responce + System.lineSeparator());
//					}else if(message.equals(Protocol.changePasswordError)) {
//						System.out.println("[SERVER WROTE] : " + message );
//					}
//					else if(message.equals(Protocol.customerRegistrationRequestAccepted)) {
//						System.out.println("[SERVER WROTE] : " + message + System.lineSeparator());
//						sendMessage(Protocol.customerRegistrationData);
//						User u = (User) RegistrationHandler.getInstance().startRegistrationProcedure(scanner, Protocol.CUSTOMER_TYPE);
//						System.out.println(u.getNome() + " " + u.getCognome());
//						ObjectOutputStream objOut = new ObjectOutputStream(socket.getOutputStream());
//						objOut.writeObject(u);
//						objOut.flush();
//					}else if(message.equals(Protocol.staffRegistrationRequestAccepted)) {
//						System.out.println("[SERVER WROTE] : " + message + System.lineSeparator());
//						sendMessage(Protocol.staffRegistrationData);
//						Place p = (Place) RegistrationHandler.getInstance().startRegistrationProcedure(scanner, Protocol.STAFF_TYPE);
//						System.out.println(p.getNomeNegozio() + " " + p.getCitta());
//						ObjectOutputStream objOut = new ObjectOutputStream(socket.getOutputStream());
//						objOut.writeObject(p);
//						objOut.flush();
//					}else if(message.equals(Protocol.customerAddedToDatabase)) {
//						System.out.println("[SERVER WROTE] : " + message + System.lineSeparator());
//						
//					}else if(message.equals(Protocol.staffAddedToDatabase)) {
//						System.out.println("[SERVER WROTE] : " + message + System.lineSeparator());
//					}else if(message.equals(Protocol.loginRequestAccepted)) {
//						System.out.println("[SERVER WROTE] : " + message + System.lineSeparator());
//						sendMessage(Protocol.loginData);
//						LoginUser lu = (LoginUser) RegistrationHandler.getInstance().loginProcedure(scanner);
//						ObjectOutputStream objOut = new ObjectOutputStream(socket.getOutputStream());
//						objOut.writeObject(lu);
//						objOut.flush();
//					}else if(message.equals(Protocol.loginSuccess)) {
//						System.out.println("[CLIENT] login effettuato con SUCCESSO! " + message + System.lineSeparator());	
//					}else if(message.equals(Protocol.loginCredentialError)) {
//						System.out.println("[CLIENT] :" + Protocol.loginCredentialError + System.lineSeparator());
//					}else if(message.equals(Protocol.userDontExistError)) {
//						System.out.println("[CLIENT] :" + Protocol.userDontExistError + System.lineSeparator());
//					}else if(message.equals(Protocol.userExistError)) {
//						System.out.println("[CLIENT] :" + Protocol.userExistError + System.lineSeparator());
//					}else if(message.equals(Protocol.customerDashboard)) {
//						
//						
//						
//						System.out.println("[CLIENT] :" + "[CUSTOMER]" + System.lineSeparator());
//						ObjectInputStream objIn = new ObjectInputStream(socket.getInputStream());
//						User u = (User) objIn.readObject();
//						if(u != null)
//						System.out.println("Nome : " + u.getNome() + " , Cognome : " + u.getCognome());
//						sendMessage(Protocol.getPlaceRequest);
//						sendMessage(u.getCitta());
//						objIn = new ObjectInputStream(socket.getInputStream());
//						Places places = (Places) objIn.readObject();
//						
//						System.out.println("I negozi nella tua zona: ");
//						for(int i = 0; i < places.places.size(); ++i)
//							System.out.println("Negozio " + i + " : Nome Negozio = " + places.places.get(i).getNomeNegozio() + " Valutazione = " + places.places.get(i).getValutazione() + System.lineSeparator() );
//						System.out.println("Inserisci il numero del negozio che vuoi visitare");
//						String choose = scanner.next();
//						Place p = places.places.get(Integer.parseInt(choose));
//						sendMessage(Protocol.getJobsRequest);
//						sendMessage(p.getNomeNegozio());
//						objIn = new ObjectInputStream(socket.getInputStream());
//						Jobs jobs = (Jobs) objIn.readObject();
//						System.out.println("Jobs : ");
//						for(int i = 0; i < jobs.jobs.size(); ++i)
//							System.out.println("Job " + i + " : Nome Job = " + jobs.jobs.get(i).getNomePrestazione() + " , Prezzo : " + jobs.jobs.get(i).getCosto() + System.lineSeparator() );
//						String j;
//						Reservation reservation;
//						Jobs job = new Jobs();
//						do {
//							j = scanner.next();
//							if(j.equals("fine")) break;
//							job.jobs.add(jobs.jobs.get(Integer.parseInt(j)));
//						}while(true);
//						
//						for(int i = 0; i < job.jobs.size(); ++i)
//							System.out.println("Job " + i + " : Nome Job = " + job.jobs.get(i).getNomePrestazione() + " , Prezzo : " + job.jobs.get(i).getCosto() + System.lineSeparator() );
//						System.out.println("Inserisci l'orario");
//						String orario = scanner.next();
//						System.out.println("Inserisci la data");
//						String data = scanner.next();
//						reservation = new Reservation(u.getUsername(), p.getNomeNegozio(), job, orario, data);
//						sendMessage(Protocol.addReservationRequest);
//						sendMessage(reservation.getCliente());
//						sendMessage(reservation.getNegozio());
//						sendMessage(reservation.getOra());
//						sendMessage(String.valueOf(job.jobs.size()));
//						sendMessage(reservation.getData());
//						
//						for(int i = 0; i < job.jobs.size(); ++i) {
//							sendMessage(job.jobs.get(i).getCosto());
//							sendMessage(job.jobs.get(i).getNomePrestazione());
//							sendMessage(job.jobs.get(i).getTempoEsecuzione());
//						}
//						
//						
//					}else if(message.equals(Protocol.reservationNotAvailableError)){
//						System.out.println("[SERVER WROTE] : " + Protocol.reservationNotAvailableError );
//						
//					} else if(message.equals(Protocol.staffDashboard)){
//						
//						
//						
//						System.out.println("[CLIENT] :" + "[STAFF]" + System.lineSeparator());
//						ObjectInputStream objIn = new ObjectInputStream(socket.getInputStream());
//						Place p = (Place) objIn.readObject();
//						if(p != null)
//						System.out.println("Nome : " + p.getNomeNegozio() + " , Città : " + p.getCitta());
//						
//						//AGGIUNTA DI UN JOB
//						
//						Job j = new Job("shampoo", "5", "5", p.getNomeNegozio());
//						sendMessage(j.getNomePrestazione());
//						sendMessage(j.getCosto());
//						sendMessage(j.getPlaceName());
//						sendMessage(j.getTempoEsecuzione());
////						System.out.println("[SERVER WROTE] : " + in.readLine());
//						
//						
//						//DISPLAY ALL JOBS
//						int i = 0;
//						System.out.println("Prestazioni aggiunte : " + System.lineSeparator());
//						do {
//							String nomePrestazione = in.readLine();
//							String costoPrestazione = in.readLine();
//							String placeNamePrestazione = in.readLine();
//							String tempoEsecuzionePrestazione = in.readLine();
//							if(nomePrestazione == null) break;
//							System.out.println("JOB " + i + " : " + nomePrestazione + " " + costoPrestazione + " " + placeNamePrestazione + " " + tempoEsecuzionePrestazione);
//							i++;
//						}while(true);
//						
//						
//					}else if(message.equals(Protocol.jobAdded)) {
//						System.out.println("[CLIENT] : Job aggiunto correttamente");
//					}
//			} catch (IOException e) {
//				System.out.println("[CLIENT] : Errore di connessione" + System.lineSeparator());
//				e.printStackTrace();
//				return;
//			} catch (ClassNotFoundException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} 
//		}
//		
//		
//	}
//	
	
	
}
