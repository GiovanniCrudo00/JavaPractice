package Application.logic;

import java.io.Serializable;

public class Job implements Serializable{
	private static final long serialVersionUID = -9160358955468452791L;
	
//	a)	Il nome della prestazione
//	b)	Il costo
//	c)	Il tempo medio di esecuzione della prestazione
	
	String placeName;
	String nomePrestazione;
	String costo;
	String tempoEsecuzione;
	String nomeParrucchiereAssegnato;
	String eliminato;
	
	
	
	
	public Job(String nomePrestazione, String costo, String tempoEsecuzione, String placeName, String eliminato) {
		super();
		this.placeName = placeName;
		this.nomePrestazione = nomePrestazione;
		this.costo = costo;
		this.tempoEsecuzione = tempoEsecuzione;
		this.eliminato = eliminato;
	}
	
	public String getEliminato() {
		return this.eliminato;
	}
	
	public String getPlaceName() {
		return placeName;
	}

	public void setPlaceName(String placeName) {
		this.placeName = placeName;
	}

	public String getNomePrestazione() {
		return nomePrestazione;
	}
	public void setNomePrestazione(String nomePrestazione) {
		this.nomePrestazione = nomePrestazione;
	}
	public String getCosto() {
		return costo;
	}
	public void setCosto(String costo) {
		this.costo = costo;
	}
	public String getTempoEsecuzione() {
		return tempoEsecuzione;
	}
	public void setTempoEsecuzione(String tempoEsecuzione) {
		this.tempoEsecuzione = tempoEsecuzione;
	}
	public String getNomeParrucchiere() {
		return nomeParrucchiereAssegnato;
	}
	public void setNomeParrucchiere(String nomeParrucchiere) {
		this.nomeParrucchiereAssegnato = nomeParrucchiere;
	}
}
