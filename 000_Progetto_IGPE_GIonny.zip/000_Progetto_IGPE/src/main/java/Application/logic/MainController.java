package Application.logic;

import Application.controller.CustomerDashboardController;

public class MainController {
	CustomerDashboardController customerDashboardController = null;
	private static MainController instance = null;
	
	
	private MainController() {}
	
	public void setCustomerDashboardController(CustomerDashboardController controller) {
		this.customerDashboardController = controller;
	}
	
	public static MainController getInstance() {
		if(instance == null)
			instance = new MainController();
		return instance;
	}
	
	public void addShopsToDashboard() {
		//customerDashboardController.init();
	}
}
