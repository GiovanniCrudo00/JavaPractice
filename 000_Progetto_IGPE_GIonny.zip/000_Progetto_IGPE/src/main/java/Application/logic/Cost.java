package Application.logic;

import java.io.Serializable;

public class Cost implements Serializable{

	private static final long serialVersionUID = 905840922318056004L;
	private String shopName;
	private String motivo;
	private String importo;
	private String data;
	public Cost(String shopName, String motivo, String importo, String data) {
		super();
		this.shopName = shopName;
		this.motivo = motivo;
		this.importo = importo;
		this.data = data;
	}
	
	
	public String getData() {
		return data;
	}


	public void setData(String data) {
		this.data = data;
	}


	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getMotivo() {
		return motivo;
	}
	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}
	public String getImporto() {
		return importo;
	}
	public void setImporto(String importo) {
		this.importo = importo;
	}
	

}
