package Application.logic;

import java.io.Serializable;
import java.util.Vector;


public class Reservations implements Serializable{
	private static final long serialVersionUID = 5714486091564042554L;
	
	public Vector<Reservation> reservations;
	public Reservations() {
		reservations = new Vector<Reservation>();
	}

}
