package Application.logic;

import Application.net.common.User;

public class ReservationHandler {
	private Reservation reservation;
	private static ReservationHandler instance = null;
	
	
	private ReservationHandler() {
	}
	
	public static ReservationHandler getInstance() {
		if(instance == null)
			instance = new ReservationHandler();
		return instance;
	}
	
	public void setReservation(User u, String p) {
		this.reservation = new Reservation(u.getUsername(), p);
		reservation.setCliente(u.getUsername());
		reservation.setNegozio(p);
	}
	
	public Reservation getReservation() {
		return this.reservation;
	}
	
	@Override
	public String toString() {
		String s = reservation.getNegozio() + " " + reservation.getCliente() + " " + reservation.getData() + " "+ reservation.getOra() + " " ;
		for(int i = 0; i < reservation.getJobs().jobs.size(); i++) {
			s += reservation.getJobs().jobs.get(i).getNomePrestazione() + " ";
		}
		return s;
	}
}
