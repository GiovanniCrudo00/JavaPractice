package Application.logic;
import java.util.Scanner;

import org.springframework.security.crypto.bcrypt.BCrypt;

import Application.net.common.LoginUser;
import Application.net.common.Place;
import Application.net.common.Protocol;
import Application.net.common.User;

public class RegistrationHandler {
	
	Scanner scanner;
	static private RegistrationHandler handler;
	
	
	private RegistrationHandler() {
	}
	
	public static RegistrationHandler getInstance() {
		if(handler == null)
			handler = new RegistrationHandler();
		return handler;
	}
	
	public LoginUser loginProcedure(Scanner scanner) {
		System.out.println("[LOGIN] : Inserisci Username : ");
		String username = scanner.next();
		System.out.println("[LOGIN] : Inserisci Password : ");
		String password = scanner.next();
		return new LoginUser(username, password);
	}
	
	public Object startRegistrationProcedure(Scanner scanner, int registrationType) {
		this.scanner = scanner;
		
		if(registrationType == Protocol.CUSTOMER_TYPE) {
			//Se vuoi effettuare la registrazione come cliente
			System.out.println("[REGISTRATION HANDLER] : Registrazione in Customer Mode.");
			
			//Inserisco tutti i miei dati 
			//a)	Nome
			//b)	Cognome
			//c)	Data di nascita
			//d)	Indirizzo 
			//e)	Città di residenza (verrà utilizzata per il suggerimento dei locali)
			//f)	E-mail
			//g)	Username (univoco, generato automaticamente)
			//h)	Password
			String nome = "Andrea", cognome = "Marasco",
				   dataDiNascita = "2001-04-12", indirizzo = "via Carlo V",
				   numeroCivico = "72", citta = "Catanzaro", mail = "marasco.andrea@gmail.com",
				   username = "andrea", password = "andrea";
			
			//Cripto la password
			String criptedPassword = BCrypt.hashpw(password, BCrypt.gensalt(12));
			System.out.println(criptedPassword + System.lineSeparator());
			return new User(nome,cognome, dataDiNascita, indirizzo, numeroCivico, citta, mail, username, criptedPassword);
			
			//return new User(nome, cognome, dataDiNascita, indirizzo, numeroCivico, citta, mail, username, criptedPassword);
		}else if(registrationType == Protocol.STAFF_TYPE) {
			//Se vuoi effettuare la registrazione come personale
			System.out.println("[REGISTRATION HANDLER] : Registrazione in Staff Mode.");
			String nomeNegozio = "CoiffeurSara";
			Float valutazione = (float) 4.8; // scala 1 - 5
			String orarioInizio = "9:00";
			String orarioFine = "19:00";
			String citta = "Catanzaro";
			String cap = "88100";
			String via = "via brigata catanzaro";
			String numeroCivico = "1"; 
			String password = "sara";
			String mail = "a.b@c.d";
			String criptedPassword = BCrypt.hashpw(password, BCrypt.gensalt(12));
			System.out.println(criptedPassword + System.lineSeparator());
			return new Place(nomeNegozio, valutazione, orarioInizio, orarioFine, citta, cap, via, numeroCivico, criptedPassword, mail);
		}else {
			//Se provi a fare qualunque altra cosa
			System.out.println("[REGISTRATION HANDLER] Attenzione! Azione non consentita!");
			return new User();
		}
	}
	
}
