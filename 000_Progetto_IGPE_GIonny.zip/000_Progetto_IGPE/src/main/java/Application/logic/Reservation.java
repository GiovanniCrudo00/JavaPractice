package Application.logic;

import java.io.Serializable;

import Application.net.common.Jobs;


public class Reservation implements Serializable{
	private static final long serialVersionUID = -703050332062572495L;
	
	private Jobs jobs;
	private String cliente;
	private String negozio;
	private String ora;
	private String data;
	private String accettato;

	
	public Reservation(String u, String p, Jobs j, String o, String data, String accettato) {
		this.jobs = j;
		this.cliente = u;
		this.negozio = p;
		this.ora = o;
		this.data = data;
		this.accettato = accettato;
	}
	
	public Reservation(String u, String p) {
		this.cliente = u;
		this.negozio = p;
		this.jobs = new Jobs();
	}
	
	@Override
	public String toString() {
		StringBuilder string = new StringBuilder();
		string.append(cliente + " " + negozio + " " + ora + " " + data + " " + accettato + " ");
		for(int i = 0; i < jobs.jobs.size(); ++i)
			string.append(" " + jobs.jobs.get(i).getNomePrestazione());
		return string.toString();
	}
	
	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public void addJob(Job j) {
		this.jobs.jobs.add(j);
	}
	public void removeJob(Job j) {
		this.jobs.jobs.remove(j);
	}
	public Jobs getJobs() {
		return jobs;
	}

	public void setJobs(Jobs jobs) {
		this.jobs = jobs;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public String getNegozio() {
		return negozio;
	}

	public void setNegozio(String negozio) {
		this.negozio = negozio;
	}

	public String getOra() {
		return ora;
	}

	public void setOra(String ora) {
		this.ora = ora;
	}
	
	public void setAccettato(String accettato) {
		this.accettato = accettato;
	}
	
	public String getAccettato() {
		return this.accettato;
	}

}
