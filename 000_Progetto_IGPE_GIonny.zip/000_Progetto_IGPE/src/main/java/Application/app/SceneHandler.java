package Application.app;

import java.io.IOException;

import Application.controller.JobCardController;
import Application.controller.JobShopCardController;
import Application.controller.ModifyJobController;
import Application.controller.MyReservationPageController;
import Application.controller.ReservationCardController;
import Application.controller.ReservationPageController;
import Application.controller.ReservationShopCardController;
import Application.controller.ShopCardController;
import Application.controller.ShopPageController;
import Application.logic.Reservations;
import Application.net.common.Jobs;
import Application.net.common.Place;
import Application.net.common.Places;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class SceneHandler {
	
	private Stage stage;
	private Stage secondStage;
	private Scene scene;
	

	private static SceneHandler instance = null;
	
	
	private SceneHandler() {}
	
	public void init(Stage primaryStage) throws Exception{
		stage = primaryStage;
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/Login.fxml"));
    	Parent root = (Parent) loader.load();
		scene = new Scene(root, 700, 400);
		stage.setScene(scene);
		stage.setResizable(false);
		stage.setTitle("Login");
		stage.show();
	}
	
	public void setLoginScene() throws Exception{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/Login.fxml"));
		Parent root = (Parent) loader.load();
		scene.setRoot(root);
		stage.hide();
		stage.setScene(scene);
		stage.setResizable(false);
		stage.setTitle("Login");
		stage.show();
	}
	
	public void initReservationDialog(Place p) throws Exception{
		secondStage = new Stage();
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/ReservationPage.fxml"));
		ReservationPageController controller = loader.getController();
		controller.p = p;
    	Parent root = (Parent) loader.load();
		Scene scene = new Scene(root);
		secondStage.setScene(scene);
		secondStage.setResizable(false);
		secondStage.setTitle("Reservation");
		secondStage.show();
	}
	
	public static SceneHandler getInstance() {
		if(instance == null)
			instance = new SceneHandler();
		return instance;
	}
	
	public void setRegistrationScene() throws Exception{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/Registration.fxml"));
		Parent root = (Parent) loader.load();
		scene.setRoot(root);
		stage.hide();
		stage.setScene(scene);
		stage.setResizable(false);
		stage.setTitle("Register");
		stage.show();
	}
	
	public void setCustomerRegistrationScene() throws Exception{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/CustomerRegistration.fxml"));
		Parent root = (Parent) loader.load();
		scene.setRoot(root);
		stage.hide();
		stage.setScene(scene);
		stage.setResizable(false);
		stage.setTitle("Register");
		stage.show();
	}
	
	public void setShopRegistrationScene() throws Exception{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/ShopRegistration.fxml"));
		Parent root = (Parent) loader.load();
		scene.setRoot(root);
		stage.hide();
		stage.setScene(scene);
		stage.setResizable(false);
		stage.setTitle("Register");
		stage.show();
	}
	
	public void setFetchPasswordScene() throws Exception{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/fetchPassword.fxml"));
		Parent root = (Parent) loader.load();
		scene.setRoot(root);
		stage.hide();
		stage.setScene(scene);
		stage.setResizable(false);
		stage.setTitle("Fetch password");
		stage.show();
	}
	
	public void setFetchPasswordCodeScene() throws Exception{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/FetchPasswordCode.fxml"));
		Parent root = (Parent) loader.load();
		System.out.println(loader.getController());
		scene.setRoot(root);
		stage.hide();
		stage.setScene(scene);
		stage.setResizable(false);
		stage.setTitle("Fetch password");
		stage.show();
	}
	
	public void setResetPasswordScene() throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/ResetPasswordScene.fxml"));
		Parent root = (Parent) loader.load();
		scene.setRoot(root);
		stage.hide();
		stage.setScene(scene);
		stage.setResizable(false);
		stage.setTitle("Fetch password");
		stage.show();
	}
	
	public void setCustomerDashboard() throws IOException{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/CustomerDashboard.fxml"));
		Parent root = (Parent) loader.load();
		scene.setRoot(root);
		stage.hide();
		stage.setHeight(512);
		stage.setWidth(1024);
		stage.setScene(scene);
		stage.setResizable(true);
		stage.setTitle("Customer Dashboard");
		stage.show();
	}
	
	public void setShopDashboard() throws IOException{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/ShopDashboard.fxml"));
		Parent root = (Parent) loader.load();
		scene.setRoot(root);
		stage.hide();
		stage.setHeight(512);
		stage.setWidth(1024);
		stage.setScene(scene);
		stage.setResizable(true);
		stage.setTitle("Shop Dashboard");
		stage.show();
	}
	
	public void setShopDashboardCost() throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/ShopDashboardCost.fxml"));
		Parent root = (Parent) loader.load();
		scene.setRoot(root);
		stage.hide();
		stage.setHeight(512);
		stage.setWidth(1024);
		stage.setScene(scene);
		stage.setResizable(true);
		stage.setTitle("Shop Dashboard");
		stage.show();
	}
	
	public void setShopDashboardHome() throws IOException{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/ShopDashboardHome.fxml"));
		Parent root = (Parent) loader.load();
		scene.setRoot(root);
		stage.hide();
		stage.setHeight(512);
		stage.setWidth(1024);
		stage.setScene(scene);
		stage.setResizable(true);
		stage.setTitle("Shop Dashboard");
		stage.show();
	}
	
	
	public Parent getShopCard(Place p, int i, Places places) throws IOException{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/ShopCard.fxml"));
		ShopCardController controller = loader.getController();
		controller.p = p;
		controller.i = i;
		controller.places = places;
		return (Parent) loader.load();
	}
	
	public Parent getJobShobCard(Jobs j, int i) throws IOException{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/JobShopCard.fxml"));
		JobShopCardController controller = loader.getController();
		controller.j = j;
		controller.i= i;
		return (Parent) loader.load();
	}
	
	public void setReservationsPage(Reservations res) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/MyReservationPage.fxml"));
		MyReservationPageController controller = loader.getController();
		controller.res = res;
		Parent root = (Parent) loader.load();
		scene.setRoot(root);
		stage.hide();
		stage.setHeight(512);
		stage.setWidth(1024);
		stage.setScene(scene);
		stage.setResizable(true);
		stage.setTitle("Customer Dashboard");
		stage.show();
	}
	
	
	public void setShopPage(int i, Places p) throws IOException{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/ShopPage.fxml"));
		ShopPageController controller = loader.getController();
		controller.index = i;
		controller.p = p;
		Parent root = (Parent) loader.load();
		scene.setRoot(root);
		stage.hide();
		stage.setScene(scene);
		stage.setResizable(true);
		stage.setTitle("Shop Page");
		stage.show();
	}
	
	
	public Parent getJobCard(Jobs j, int i) throws IOException{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/JobCard.fxml"));
		JobCardController controller = loader.getController();
		controller.j = j;
		controller.i= i;
		return (Parent) loader.load();
	}
	
	public Parent getReservationCard(int index, Reservations reservations) throws IOException{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/ReservationCard.fxml"));
		ReservationCardController controller = loader.getController();
		controller.reservations = reservations;
		controller.i = index;
		return (Parent) loader.load();
	}
	
	public Parent getReservationShopCard(int index, Reservations reservations) throws IOException{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/ReservationShopCard.fxml"));
		ReservationShopCardController controller = loader.getController();
		controller.res = reservations;
		controller.i= index;
		return (Parent) loader.load();
	}
	
	public void initModifyJobDialog(Jobs j, int i) throws Exception{
		secondStage = new Stage();
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Application/view/ModifyJob.fxml"));
		ModifyJobController controller = loader.getController();
		controller.j = j;
		controller.i = i;
    	Parent root = (Parent) loader.load();
		Scene scene = new Scene(root);
		secondStage.setScene(scene);
		secondStage.setResizable(false);
		secondStage.setTitle("Reservation");
		secondStage.show();
	}
	
	
	
	public void showError(String message) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("Error");
		alert.setHeaderText("");
		alert.setContentText(message);
		alert.show();
	}
	
	public void showDialog(String message) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Prenotazione aggiunta");
		alert.setHeaderText("");
		alert.setContentText(message);
		alert.show();
	}

	

	
}
