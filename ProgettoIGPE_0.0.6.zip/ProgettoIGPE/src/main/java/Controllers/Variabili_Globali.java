package Controllers;
import java.sql.SQLException;

import Application.*;
public class Variabili_Globali {
	public static User User_Online;
	public static User TeamLeader;
	public static boolean isDark=false;
	public static  boolean getisDark() throws SQLException {
		return Database.wantsDarkMode(User_Online);
	}
	public static void setIsDark(int A) throws SQLException {
		Database.setDarkMode(A);
	}
	public static User getUser_Online() {
		return User_Online;
	}
	public static User getTeamLeader() {
		return TeamLeader;
	}

	public static void setTeamLeader(User teamLeader) {
		TeamLeader = teamLeader;
	}

	public static void logIn(User user_Online) throws NullPointerException, SQLException{
		User_Online = user_Online;
	}
	public static void logOut() {
		User_Online = null;
	}
	
	

}
