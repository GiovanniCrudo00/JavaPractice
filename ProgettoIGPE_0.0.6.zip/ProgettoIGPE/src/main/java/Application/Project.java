package Application;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
public class Project {
	private String Nome;
	private ArrayList<String> TypeofIssues;
	private ArrayList<User> Users; 
	private String ProjectManager; 
	private ArrayList<Ticket> ticketsAssociati;
	//----------------------------------------
	public Project(){
		this.Nome=" ";
		this.TypeofIssues=new ArrayList<String>();
		this.Users=new ArrayList<User>();
		this.ProjectManager="";
		this.ticketsAssociati=new ArrayList<Ticket>();
	}
	@SuppressWarnings("unchecked")
	public Project(String N,ArrayList<String> TOI,ArrayList<User> U,ArrayList<String> A,ArrayList<Ticket> T){
		this.Nome=N;
		this.TypeofIssues=(ArrayList<String>) TOI.clone();
		this.Users=(ArrayList<User>) U.clone();
		this.ProjectManager="";
		this.ticketsAssociati=(ArrayList<Ticket>) T.clone();
	}
	public String getPM() {
		return this.ProjectManager;
	}
	public void setPm(String PM) {
		this.ProjectManager=PM;
	}
	public void addTypeOfIssue(String issue) {TypeofIssues.add(issue);}
	public void addUsers(User user) {Users.add(user);}
	public void setNome(String nome) {this.Nome=nome;}
	public String getNome() {return this.Nome;}
	public ArrayList<String> getIssues() {return this.TypeofIssues;}
	public ArrayList<User> getUsers(){return this.Users;}
	public String getAdmin(){return this.ProjectManager;}
	public void setTypeofIssues(ArrayList<String> toTokenize) {
		this.TypeofIssues=toTokenize;
	}
	public void setUsers(ArrayList<String> toTokenize) throws SQLException {
		ArrayList<String> nomiUser;
		nomiUser=toTokenize;
		for (String UserDelProgetto : nomiUser) {
			Users.add(Database.getUser(UserDelProgetto));
		}
	}
	
	public String toString() {
		String A=this.Nome+" "+ this.TypeofIssues+" "+this.Users+ " "+this.ProjectManager;
		return A;
	}
	public Project clone(String N,ArrayList<String> TOI,ArrayList<User> U,String A){
			this.Nome=N;
			Collections.copy(this.TypeofIssues,TOI);
			Collections.copy(this.Users, U);
			this.ProjectManager=A;
			return this;
	}
	public ArrayList<Ticket> getTicketsAssociati() {
		return ticketsAssociati;
	}
	public void setTicketsAssociati(ArrayList<Ticket> ticketsAssociati) {
		this.ticketsAssociati = ticketsAssociati;
	}
	
		

}

