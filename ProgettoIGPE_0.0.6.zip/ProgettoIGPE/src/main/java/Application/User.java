package Application;

import java.util.ArrayList;

public class User {
	protected String Username;
	protected String Nome;
	protected String Cognome;
	protected String Email;
	protected int Ruolo;	
	protected String propic;
public ArrayList<String> getInfos() {
		// 1.Username,2.Nome,3.Cognome,4.Email,5.Ruolo,6.propic
		ArrayList<String> UserInfos=new ArrayList<>();
		UserInfos.add(this.Username);
		UserInfos.add(this.Nome);
		UserInfos.add(this.Cognome);
		UserInfos.add(this.Email);
		Integer Ruolo1=this.Ruolo;
		UserInfos.add(Ruolo1.toString());
		UserInfos.add(this.propic);
		return UserInfos;
	}
	public String getPropic() {
		return propic;
	}
	public void setPropic(String propic) {
		this.propic = propic;
	}
	public User(String username, String nome, String cognome, String email, String ruolo) {
		super();
		Username = username;
		Nome = nome;
		Cognome = cognome;
		Email = email;
		Ruolo = 0;
	}
	public User() {
		super();
		Username = "";
		Nome = "";
		Cognome = "";
		Email = "";
		Ruolo = 0;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public String getCognome() {
		return Cognome;
	}
	public void setCognome(String cognome) {
		Cognome = cognome;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public int getRuolo() {
		return Ruolo;
	}
	public void setRuolo(String ruolo) {
		if (ruolo.equals("Project Manager")) Ruolo=1;
		else Ruolo = 0;
	}
	public boolean hasPermission() {
		if (Ruolo>=1) {
			return true;
		}
		return false;
	}
	public boolean isTL() {
		if (Ruolo==2) return true;
		else return false;
	}
	public boolean isAdmin() {
		if (Ruolo==1) return true;
		else return false;
	}

	

}
