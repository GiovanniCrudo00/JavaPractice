package Application;

import java.sql.SQLException;
import java.util.ArrayList;

public class Ticket {
	//-----------------------------------------------
	//attributi
	private String ID;
	private String Creator;
	private int Priority;
	private ArrayList <String> LinkedTickets;
	private ArrayList <String> Keywords;
	private String Description;
	private Project ProgettoAssociato;
	//--------------------------------------------------------------------
	//metodi
	public String getID() {return ID;}
	public void setID(String iD) {ID = iD;}
	public String getCreator() {return Creator;}
	public void setCreator(String Creator) {this.Creator = Creator;}
	public int getPriority() {return Priority;}
	public void setPriority(int priority) {Priority = priority;}
	public ArrayList<String> getLinkedTickets() {return LinkedTickets;}
	public void setLinkedTickets(ArrayList<String> linkedTickets) {LinkedTickets = linkedTickets;}
	public ArrayList<String> getKeywords() {return Keywords;}
	public void setKeywords(ArrayList<String> keywords) {Keywords = keywords;}
	public String getDescription() {return Description;}
	public void setDescription(String description) {Description = description;}
	public Ticket() {
		 ID="";
		 Creator="";
		 Priority=-1;
		 LinkedTickets=new ArrayList<String>();
		 Keywords=new ArrayList<String>();
		 Description="";
		 ProgettoAssociato=new Project();
	}
	public Project getProgettoAssociato() {
		return ProgettoAssociato;
	}
	public void setProgettoAssociato(Project project) throws SQLException {
		ProgettoAssociato = project;
	}
	
	

}
