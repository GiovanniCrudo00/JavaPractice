package Application;

import java.sql.SQLException;

public class Admin extends User {
		private Project Progetto;
		public Admin(String username, String nome, String cognome, String email, String ruolo,String nomeProgetto) throws SQLException {
			super(username,nome,cognome,email,"admin");
			if (!(nomeProgetto.isBlank()))this.setProgetto(Database.GetProject(nomeProgetto));
			else this.setProgetto(null);
	}
		public Project getProgetto() {
			return Progetto;
		}
		public void setProgetto(Project progetto) {
			Progetto = progetto;
		}

}
