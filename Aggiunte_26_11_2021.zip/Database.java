package Application;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.springframework.security.crypto.bcrypt.BCrypt;

import Controllers.Variabili_Globali;
public class Database {
	public static void insertUsers(String Username,String Password,String Nome,String Cognome,String Email) {
		Connection con=DbConnection.getInstance().getCon();
		PreparedStatement ps=null;
		try {
			String PasswordCrypted=CryptPass(Password);
			String sql="INSERT INTO users (Username,Password,Nome,Cognome,Email) VALUES(?,?,?,?,?) ";
			ps = con.prepareStatement(sql);
			ps.setString(1, Username);
			ps.setString(2, PasswordCrypted);
			ps.setString(3, Nome);
			ps.setString(4, Cognome);
			ps.setString(5, Email);
			ps.execute();
			ps.close();
			System.out.println("Utente aggiunto!");
		}
		catch(SQLException e){System.out.println(e.toString());}
	}
	public static String CryptPass(String originalPassword) {
		 String Crypted= BCrypt.hashpw(originalPassword, BCrypt.gensalt(12));
		 return Crypted;		
	}
	public static Boolean userExists(String user) throws SQLException {
		String sql = "SELECT * FROM Users WHERE Username=? ;";
		Connection con=DbConnection.getInstance().getCon();
		PreparedStatement ps=null;
		ps=con.prepareStatement(sql);
		ps.setString(1, user);
		ResultSet rs= ps.executeQuery();
		if(!rs.next()) {
			ps.close();
			return false;
		}
		ps.close();
		return true;
	}
	public static User getUser(String nome) throws SQLException{
		String sql = "SELECT * FROM Users WHERE Username=?;";
		Connection con=DbConnection.getInstance().getCon();
		PreparedStatement ps=null;
		ps=con.prepareStatement(sql);
		ps.setString(1, nome);
		ResultSet rs= ps.executeQuery();
		User A=new User();
		A.setUsername(nome);
		A.setNome(rs.getString(3));
		A.setEmail(rs.getString(5));
		A.setCognome(rs.getString(4));
		A.setRuolo(rs.getString(6));
		A.setPropic(rs.getString(7));
		ps.close();
		return A;
	}
	public static ArrayList<User> getAllUsers() throws SQLException{
		String sql = "SELECT * FROM Users;";
		Connection con=DbConnection.getInstance().getCon();
		PreparedStatement ps=null;
		ps=con.prepareStatement(sql);
		ResultSet rs= ps.executeQuery();
		ArrayList<User> Users=new ArrayList<User>();
		while(rs.next()) {
			User A=new User();
			A.setUsername(rs.getString(1));
			A.setNome(rs.getString(3));
			A.setEmail(rs.getString(5));
			A.setCognome(rs.getString(4));
			A.setRuolo(rs.getString(6));
			A.setPropic(rs.getString(7));
			Users.add(A);
		}
		ps.close();
		return Users;
	}
 	public static boolean addPropic(String URL,String name) throws IOException {
		String sql = "update users set ProPic=? where Username=?;";
		try {Connection con=DbConnection.getInstance().getCon();
		PreparedStatement ps=null;
		ps=con.prepareStatement(sql);
			ps.setString(1, URL);
			ps.setString(2, name);
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	public static ArrayList<String> getTlInfo() throws SQLException{
		String sql = "SELECT * FROM Users WHERE Username=? ;";
		Connection con=DbConnection.getInstance().getCon();
		PreparedStatement ps=null;
		ps=con.prepareStatement(sql);
		String user=Variabili_Globali.getTeamLeader().getUsername();
		ps.setString(1, user);
		ResultSet rs= ps.executeQuery();
		ArrayList<String> IdUser=new ArrayList<String>();
		IdUser.add(rs.getString(3));
		IdUser.add(rs.getString(4));
		IdUser.add(rs.getString(1));
		IdUser.add(rs.getString(5));
		IdUser.add("0");
		Integer RowCount=0;
		 sql = "SELECT * FROM Users;";
		PreparedStatement ps1=null;
		ps1=con.prepareStatement(sql);
		ResultSet rs1=ps1.executeQuery();
		while (rs1.next()) {
			RowCount++;
		}
		IdUser.add(RowCount.toString());
		IdUser.add(rs.getString(7));
		ps.close();
		ps1.close();
		return IdUser;
	}
	public static Boolean Checkuser(String user,String Pass) throws SQLException {
			String sql = "SELECT * FROM users WHERE Username=? ;";
			Connection con=DbConnection.getInstance().getCon();
			PreparedStatement ps=null;
			ps=con.prepareStatement(sql);
			ps.setString(1, user);
			ResultSet rs= ps.executeQuery();
			while(rs.next()) {
				if ( BCrypt.checkpw(Pass,rs.getString("Password"))) {
					ps.close();
					return true;
				}
				
			}
			ps.close();
			return false;
	}
	public static void insertProject(String Nome,String TOI,String Users,String PM) {
			Connection con=DbConnection.getInstance().getCon();
			PreparedStatement ps=null;
			try {
				String sql="INSERT INTO progetto (Nome,TypeOfIssues,Users,ProjectManager) VALUES(?,?,?,?) ;";
				ps = con.prepareStatement(sql);
				ps.setString(1, Nome);
				ps.setString(2, TOI);
				ps.setString(3, Users);
				ps.setString(4, PM);
				ps.execute();
				ps.close();
				System.out.println("Progetto aggiunto!");
			} catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
	public static ArrayList<Project> GetProjects() throws SQLException {
			String sql = "SELECT * FROM progetto;";
			Connection con=DbConnection.getInstance().getCon();
			PreparedStatement ps=null;
			ps=con.prepareStatement(sql);
			ResultSet rs= ps.executeQuery();
			ArrayList<Project> Progetti=new ArrayList<Project>();
			while(rs.next()) {
				Project A=new Project();
				A.setNome(rs.getString(1));
				A.setTypeofIssues(Database.tokProject(rs.getString(2)));
				A.setUsers(Database.tokProject(rs.getString(3)));
				A.setPm(rs.getString(4));
				Progetti.add(A);
			}
			ps.close();
			return Progetti;
		}
	public static Project GetProject(String nomeProgetto) throws SQLException {
			String sql = "SELECT * FROM progetto WHERE Nome=? ;";
			Connection con=DbConnection.getInstance().getCon();
			PreparedStatement ps=null;
			ps=con.prepareStatement(sql);
			ps.setString(1, nomeProgetto);
			ResultSet rs= ps.executeQuery();
			Project A=new Project();
			A.setNome(rs.getString(1));
			A.setTypeofIssues(Database.tokProject(rs.getString(2)));
			A.setUsers(Database.tokProject(rs.getString(3)));
			A.setPm(rs.getString(4));
			ps.close();
			return A;
		}
	public void deleteProjects() {	
		Connection con=DbConnection.getInstance().getCon();
		PreparedStatement ps=null;
		try {
			String sql="DELETE FROM progetto ;";
			ps = con.prepareStatement(sql);
			ps.execute();
			ps.close();
			System.out.println("Tabella Cancellata");
			Database.insertUsers("Car_Dod", "Carmine_Dodaro1", "Carmine", "Dodaro", "crugio23@gmail.com");
		}
		catch(SQLException e){System.out.println(e.toString());}
	}
	public static void deleteAllUsers() {
		Connection con=DbConnection.getInstance().getCon();
		PreparedStatement ps=null;
		try {
			String sql="DELETE FROM users ;";
			ps = con.prepareStatement(sql);
			ps.execute();
			ps.close();
			System.out.println("Tabella Cancellata");
			Database.insertUsers("Car_Dod", "Carmine_Dodaro1", "Carmine", "Dodaro", "crugio23@gmail.com");
		}
		catch(SQLException e){System.out.println(e.toString());}
	}
	public static void insertTicket(String ID,String Creatore,int Priorit�,String Linked,String Progetto,String Descrizione) {
		Connection con=DbConnection.getInstance().getCon();
		PreparedStatement ps=null;
		try {
			String sql="INSERT INTO Ticket (ID,Creatore,Priorit�,Linked_Tickets,Descrizione,Progetto_Associato) VALUES(?,?,?,?,?,?) ";
			ps = con.prepareStatement(sql);
			ps.setString(1, ID);
			ps.setString(2, Creatore);
			ps.setInt(3, Priorit�);
			ps.setString(4, Linked);
			ps.setString(5, Descrizione);
			ps.setString(6, Progetto);
			ps.execute();
			ps.close();
			System.out.println("Ticket aggiunto!");
		}
		catch(SQLException e){System.out.println(e.toString());}
	}
	public static ArrayList<String> tokProject(String toTokenize) {
		ArrayList<String> Risultati=new ArrayList<String>();
		StringTokenizer stok = new StringTokenizer(toTokenize, ",");
		while(stok.hasMoreTokens()) {
			String token=stok.nextToken();
			Risultati.add(token);
		}
		return Risultati;
	}
	public static Ticket getTicket(String Ticket) throws SQLException{
		String sql = "SELECT * FROM Ticket WHERE ID=?;";
		Connection con=DbConnection.getInstance().getCon();
		PreparedStatement ps=null;
		ps=con.prepareStatement(sql);
		ps.setString(1, Ticket);
		ResultSet rs= ps.executeQuery();
		Ticket A=new Ticket();
		A.setID(Ticket);
		A.setCreator(rs.getString(2));
		A.setPriority(rs.getInt(3));
		A.setLinkedTickets(Database.tokProject(rs.getString(4)));
		A.setDescription(rs.getString(5));
		A.setProgettoAssociato(Database.GetProject(rs.getString(6)));
		ps.close();
		return A;
	}
	public static ArrayList <Ticket> getAllTickets() throws SQLException{
		String sql = "SELECT * FROM Ticket ;";
		Connection con=DbConnection.getInstance().getCon();
		PreparedStatement ps=null;
		ps=con.prepareStatement(sql);
		ResultSet rs= ps.executeQuery();
		ArrayList <Ticket> lista = new ArrayList<Ticket>();
		while(rs.next()) {
		Ticket A=new Ticket();
		A.setID(rs.getString(1));
		A.setCreator(rs.getString(2));
		A.setPriority(rs.getInt(3));
		A.setLinkedTickets(Database.tokProject(rs.getString(4)));
		A.setDescription(rs.getString(5));
		A.setProgettoAssociato(Database.GetProject(rs.getString(6)));
		lista.add(A);
		}
		ps.close();
		return lista;
	}
	public void deleteTickets() {	
		Connection con=DbConnection.getInstance().getCon();
		PreparedStatement ps=null;
		try {
			String sql="DELETE FROM Ticket ;";
			ps = con.prepareStatement(sql);
			ps.execute();
			ps.close();
			System.out.println("Tabella Ticket Cancellata");
		}
		catch(SQLException e){System.out.println(e.toString());}
	}
}
	
