package Controllers;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Pattern;
import Application.Database;
import Application.SceneHandler;
import Application.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
public class ControllerLogin implements Initializable{
	
    @FXML
     Button Login_Button;
    @FXML
    private Button Go_to_Registration;
    @FXML
    private AnchorPane Loginroot;
    @FXML
    private ToggleButton Dark_mode;
    @FXML
    private TextField Userane;
    @FXML
    private ImageView immagine_luce;
    @FXML
    private PasswordField Password;
    @FXML
    void Set_Registration_Page(ActionEvent event) throws Exception {
    		SceneHandler.getInstance().setRegistrationScene();
    }
    @FXML
    void Login_Attempt(ActionEvent event) throws Exception {
    	String Pass=Password.getText();
    	if (Pattern.matches( "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%_^&+=])(?=\\S+$).{8,}$", Pass)) {
    		String User=Userane.getText();
    		boolean isok=Database.Checkuser(User, Pass);
    		if(!isok) {
    			Alert errorAlert = new Alert(AlertType.ERROR);
        		errorAlert.setHeaderText("Accesso negato");
        		errorAlert.setContentText("username o password errati");
        		errorAlert.showAndWait();
    		}
    		else //if (Database.getUser(User).isTL())
    		{
    		SceneHandler.getInstance().setTLMainPageScene();
    		User A=Database.getUser(Userane.getText());
    		Variabili_Globali.logIn(A);
    		}
//	    		else if (Database.getUser(User).isAdmin()){
//	        		//implementare pagina principale Admin
//	        		}
//	    				else {
//	    					//implementare pagina principale User
//	    				}
    			
    	}
    	else {
    		Alert errorAlert = new Alert(AlertType.ERROR);
    		errorAlert.setHeaderText("Password non valida");
    		errorAlert.setContentText("la Password deve contenere almeno un numero,una lettera maiuscola,una minuscola e un carattere speciale");
    		errorAlert.showAndWait();
    	}
    }
    @FXML
    void Set_Dark(ActionEvent event) {
    	if (Dark_mode.isSelected()) {
    		Loginroot.setStyle("-fx-base:black");
    		Dark_mode_reference.isDark=true;
    		Image immagine=new Image("sole.png");
    		immagine_luce.setImage(immagine);
    	}
    	else {
    		Loginroot.setStyle("");
    		immagine_luce.setImage(null);
    		Dark_mode_reference.isDark=false;
    		Image immagine=new Image("moon-png.png");
    		immagine_luce.setImage(immagine);
    	}
    }
@Override
public void initialize(URL location, ResourceBundle resources) {
	Image immagine=new Image("moon-png.png");
	immagine_luce.setImage(immagine);
	if (Dark_mode_reference.isDark) {
		immagine=new Image("sole.png");
		immagine_luce.setImage(immagine);
		Loginroot.setStyle("-fx-base:black");
		Dark_mode.setSelected(true);
	}
	
}

}
