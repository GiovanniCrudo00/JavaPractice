package Application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class app extends Application{

	@Override
	public void start(Stage primaryStage) {
		try {
			SceneHandler.getInstance().init(primaryStage);
		} catch(Exception e) {			
		}
	}
	
	public static void main(String args[]) {
		launch(args);
	}
}
