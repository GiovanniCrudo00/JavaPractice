package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class dammiPersone 
{
	public String ottieniPersone()
	{
		String risultati="";
		try
		{
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres");
			String sql="select * from dipendenti_azienda";
			Statement st= con.createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next())
			{
				risultati+=rs.getString(1);
				risultati+=" ";
			}
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return risultati;
	}
}
